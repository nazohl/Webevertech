<?php
/******************************************
US English
Admin messsages
******************************************/

$lang['msg_logout']		= 'Loged Out Successfully!';
$lang['msg_error_occurred']	= '<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">x</button>An ERROR occurred! Please try again.</div>';

