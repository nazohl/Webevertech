<?php
/******************************************
US English
Admin messsages
******************************************/

$lang['msg_logout']				= 'Loged Out Successfully!';
$lang['msg_register_success']			= 'You Registered Successfully! You can login now.';
