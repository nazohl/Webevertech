-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2017 at 10:10 PM
-- Server version: 5.7.16
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `minorschool.advanced`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `ans_id` int(5) NOT NULL,
  `answer` text COLLATE utf8_unicode_ci,
  `ques_id` int(5) DEFAULT NULL,
  `right_ans` int(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`ans_id`, `answer`, `ques_id`, `right_ans`) VALUES
(29, 'Thomas Pink', 8, 1),
(30, 'Albert', 8, 0),
(31, 'Red Dot', 8, 0),
(32, 'Pabello', 8, 0),
(33, 'Cyan', 9, 1),
(34, 'Magenta', 9, 0),
(35, 'Yellow', 9, 0),
(36, 'Key(Black)', 9, 0),
(37, 'Sepia', 10, 1),
(38, 'Yellowish', 10, 0),
(39, 'Redish', 10, 0),
(40, 'Nothing', 10, 0),
(41, 'Purple', 11, 1),
(42, 'Blue', 11, 0),
(43, 'Red', 11, 0),
(44, 'Yellow', 11, 0),
(45, ' Umber ', 12, 1),
(46, 'Barbar', 12, 0),
(47, 'Both 1& 2', 12, 0),
(48, 'Nothing', 12, 0),
(53, 'I wait for the other person to introduce themselves.', 14, 0),
(54, 'I introduce myself with a smile and offer a handshake.', 14, 1),
(55, 'I hug the person.', 14, 0),
(56, 'Nothing', 14, 0),
(57, 'I often cross my arms over my chest.', 15, 0),
(58, ' I often lean back and turn my body away from the speaker.', 15, 0),
(59, ' I often lean slightly forward and face my body toward the speaker.', 15, 1),
(60, 'Nothing', 15, 0),
(61, 'I tend to frown a lot.', 16, 0),
(62, 'I tend to smile and use humor at appropriate times.', 16, 1),
(63, 'I tend to be serious.', 16, 0),
(64, 'Both 1& 2', 16, 0),
(65, 'I ask for specific examples and note where I need to improve.', 17, 1),
(66, ' I get angry and defensive.', 17, 0),
(67, 'I deny the problem, make excuses, or plead ignorance.', 17, 0),
(68, 'Nothing', 17, 0),
(69, 'I tell my boss directly and use examples to show him why he is wrong.', 18, 0),
(70, 'I talk to HR to document my disagreement.', 18, 0),
(71, 'I ask questions to understand why my boss has a difference perspective.', 18, 1),
(72, 'Nothing', 18, 0),
(73, ' I make eye contact.', 19, 1),
(74, 'I sometimes make eye contact.', 19, 0),
(75, 'I never make eye contact.', 19, 0),
(76, 'Both 1& 2', 19, 0),
(77, 'I hold my head still at all times.', 20, 0),
(78, ' I nod my head at appropriate times.', 20, 1),
(79, 'I nod my head constantly.', 20, 0),
(80, 'Nothing', 20, 0),
(81, ' I stand one-foot away from the person.', 21, 0),
(82, ' I stand two- to three-feet away from the person.', 21, 1),
(83, 'I stand five- to six-feet away from the person.', 21, 0),
(84, 'Nothing', 21, 0),
(85, 'I just say it.', 22, 0),
(86, 'I lead in with a positive comment first.', 22, 1),
(87, 'I say nothing.', 22, 0),
(88, 'Both 1& 2', 22, 0),
(89, '  I don’t comment on it.', 23, 0),
(90, ' I try to change the subject.', 23, 0),
(91, 'I try to relate to the person’s feelings and show sensitivity to his or her misfortune.', 23, 1),
(92, 'Nothing', 23, 0),
(100, 'Both 1& 2', 25, 0),
(101, ' Procurement of the right kind and number of persons.', 26, 0),
(98, 'Roman', 25, 0),
(99, 'Nothing', 25, 0),
(97, 'Sochi', 25, 1),
(102, 'Training and development of employees.', 26, 1),
(103, 'Integration of the interests of the personnel with that of the enterprise.', 26, 0),
(104, 'Management of customer requirements', 26, 0),
(105, ' It relieves the manager of his/her heavy workload.', 27, 0),
(106, 'It frees the manager to address more complex, higher-level needs.', 27, 0),
(107, ' Someone else is better qualified to do the task that needs to be done.', 27, 1),
(108, 'It helps create a formal organizational structure.', 27, 0),
(109, 'Cash', 28, 0),
(110, 'Debtors', 28, 1),
(111, 'Bank overdraft', 28, 0),
(112, 'Work in progress', 28, 0),
(113, 'Statement of Financial Loss', 29, 0),
(114, 'Income Statement', 29, 0),
(115, 'Statement of Retained Earnings', 29, 0),
(116, ' Statement of Cash Flow', 29, 1),
(117, 'Stock of work in progress', 30, 1),
(118, 'Plant', 30, 0),
(119, 'Debtors', 30, 0),
(120, 'Creditors', 30, 0),
(121, 'Suppliers', 31, 0),
(122, 'Heating', 31, 0),
(123, 'Sales', 31, 1),
(124, 'Closing stock', 31, 0),
(125, 'scorecard.', 32, 1),
(126, ' ledger.', 32, 0),
(127, 'matrix.', 32, 0),
(128, 'healthcheck.', 32, 0),
(129, 'Greater flexibility in responding to customer requirements', 33, 0),
(130, 'Improved productivity', 33, 1),
(131, ' Enhanced customer satisfaction', 33, 0),
(132, 'Lower staff turnover', 33, 0),
(133, 'Area manager', 34, 1),
(134, 'Specialty manager', 34, 0),
(135, 'Front-line manager', 34, 0),
(241, 'wwww', 67, 0),
(137, 'Gross profit ratio', 35, 1),
(138, 'Current ratio', 35, 0),
(139, 'Efficiency ratio', 35, 0),
(240, 'rrrrr', 67, 1),
(141, 'Set he “Show Property” of the desired widget to “true”', 36, 0),
(142, 'Drag the desired widget of the side bar', 36, 1),
(143, 'Add the Desired widget to the post', 36, 0),
(144, 'Change the source code', 36, 0),
(145, 'Directly in the post’s', 37, 0),
(146, 'in the wp-imageresize plug-in', 37, 0),
(147, 'in the admin settings ', 37, 1),
(148, 'a and b', 37, 0),
(149, 'Joomla ', 38, 1),
(150, 'Yahoo Blog ', 38, 0),
(151, 'Drupal ', 38, 0),
(152, 'Blogspot', 38, 0),
(153, 'picture', 39, 1),
(154, 'image', 39, 1),
(155, 'img', 39, 0),
(156, 'src', 39, 0),
(157, 'Nothing', 39, 0),
(158, '<strong>', 40, 1),
(159, '<dar>', 40, 1),
(160, '<html>', 41, 1),
(161, '<head>', 41, 1),
(162, ' <title>', 41, 0),
(163, '<body>', 41, 0),
(164, '<hr>', 42, 1),
(165, '<line direction=”horizontal”>', 42, 0),
(166, ' <head>', 43, 1),
(167, '<title>', 43, 0),
(168, '<html>', 43, 0),
(169, '<document>', 43, 0),
(170, '<td> and </td>', 44, 0),
(171, '<cr> and </cr>', 44, 0),
(172, '<th> and </th>', 44, 1),
(173, '<tr> and </tr>', 44, 1),
(174, '<list>', 45, 1),
(175, '<nl>', 45, 0),
(176, '<ul>', 45, 0),
(177, '<ol>', 45, 0),
(182, 'picture', 47, 1),
(183, 'image', 47, 0),
(184, 'img', 47, 1),
(185, '<strong>', 48, 1),
(186, '<dar>', 48, 0),
(187, '<black>', 48, 0),
(188, '<emp>', 48, 1),
(189, '<html>', 49, 1),
(190, '<head>', 49, 1),
(191, '<title>', 49, 0),
(192, '<body>', 49, 0),
(193, '<hr>', 50, 0),
(194, '<line>', 50, 0),
(195, '<line direction=”horizontal”>', 50, 1),
(196, 'visited link', 51, 1),
(197, 'virtual link', 51, 0),
(198, 'very good link', 51, 0),
(199, ' active link', 51, 0),
(200, 'class', 52, 0),
(201, 'id', 52, 1),
(202, 'dot', 52, 0),
(203, 'attributes', 53, 0),
(204, 'values', 53, 1),
(205, 'tags', 53, 0),
(206, 'None of above', 53, 0),
(207, 'Couple tags', 54, 1),
(208, 'Single tags', 54, 0),
(224, 'chromatic diagram', 60, 1),
(223, 'natural diagram', 60, 0),
(225, 'color diagram', 60, 0),
(226, 'Good', 61, 1),
(227, 'Bad', 61, 0),
(228, 'Very good', 61, 0),
(229, 'Like this song', 62, 1),
(230, 'Not so good', 62, 0),
(231, 'Working fine', 63, 0),
(232, 'Not working', 63, 0),
(233, 'Love it', 63, 1),
(239, 'wwww', 66, 0),
(238, 'rrrrr', 66, 1),
(242, 'rrrrr', 68, 1),
(243, 'wwww', 68, 0),
(244, 'right', 69, 1),
(245, 'wrong', 69, 0),
(246, 'ewewewq', 70, 0),
(247, 'ewqewqeqe', 70, 1),
(248, 'Ans 1.1', 71, 1),
(249, 'Ans 1.2', 71, 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `blog_title` varchar(250) COLLATE utf8_unicode_ci DEFAULT '',
  `blog_body` text COLLATE utf8_unicode_ci,
  `author_id` int(5) DEFAULT NULL,
  `blog_post_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_title`, `blog_body`, `author_id`, `blog_post_date`) VALUES
(1, 'Everything you need to know about Envato’s Most Wanted', '<span><b>Envato''s Most Wanted</b> is an ongoing series of events and competitions we run on Envato Market, where we give authors the opportunity to win extra cash and prizes for creating awesome digital content that is in high demand on the marketplace.</span><span>So far we’ve held over <b>70 Most Wanted events</b>, and this year alone our community of talented authors have shared in <b>over $1.5 million</b> in total prizes and earnings from the items they created, with more in the making every day!<br><br></span><div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br><b>How does it work?</b><br><br></div></div>When we launch a new event, we’ll post a Most Wanted announcement on Market Blog and in the community forums explaining what kind of items we’re looking for, as well as how and where to submit them.  The event might include a race to see who can submit quality content the fastest based on specific criteria, or an overall “Best Item” contest with a massive grand prize voted on by the community or a select panel of judges.Prizes almost always include some kind of cash reward, but could also include a coveted Featured File', 1, '2014-09-30'),
(2, 'An Introduction to Google Webmaster Tools', 'The internet is a very crowded place, and amidst such crowd, it is surely not easy to get spotted by your target audience. This is where search engines come handy, and that is why more and more businesses and websites are focusing heavily on search engine optimization.However, there is more to SEO than just plugins and tweaks: you need to assess and analyze the health of your website: keywords that are returning good traffic, pages that are getting the most visits, the click-through rate of your website visitors, and so on. Furthermore, you also need to keep track of errors that search engine bots might be facing while crawling your website, sitemaps that need to be submitted, incoming links, etc.Obviously, this seems like a big deal of work. Thankfully, Google provides an array of resources that we can use to make our lives easier. Grouped together under Google Webmaster Tools, this solution provides you with complete insights about the health and performance of your website.<h2>What Can Google Webmaster Tools Do?</h2>So, what can Google Webmaster Tools do for us? A lot, but mainly:Detailed information about search queries; which keywords are performing, and which ones aren’t.Updates about crawl errors, just so you can fix them timely and avoid losing traffic.Links that are generating the maximum traffic as well as website pages that are getting most visitors.Upload and update sitemaps.For a quick overview of Webmaster Tools, check out this short video from Google:<br><br><div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</div></div></div><br><br><br>', 1, '2014-09-30'),
(4, 'TEST', '<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br></div><div><div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<br><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</div></div></div><br></div></div></div>', 1, '2017-01-27'),
(5, 'MinorSchool Blog', '<div>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><div><div><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</div><div>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div><br></div></div>', 4, '2017-03-20');

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `comment_id` int(11) NOT NULL,
  `blog_id` int(11) DEFAULT NULL,
  `comment_body` text COLLATE utf8_unicode_ci,
  `comment_author_id` int(5) DEFAULT NULL,
  `comment_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`comment_id`, `blog_id`, `comment_body`, `comment_author_id`, `comment_date`) VALUES
(1, 2, 'This is my very first comment.', 5, '2014-10-03'),
(2, 2, 'Good script', 5, '2014-10-06'),
(3, 2, 'Thanks', 5, '2014-10-19'),
(4, 2, 'Nice.', 4, '2014-11-20'),
(5, 2, 'ok', 5, '2014-11-27'),
(6, 2, 'Thank you', 2, '2014-12-03'),
(7, 1, 'Wow, nice!', 5, '2014-12-09'),
(8, 1, 'More comments', 5, '2014-12-09'),
(9, 2, 'This is a bunch of Great code.', 1, '2014-12-09'),
(10, 2, 'right ', 5, '2015-02-27'),
(11, 2, 'Good one', 3, '2015-04-16');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(5) NOT NULL,
  `category_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  `last_modified_by` int(5) DEFAULT NULL,
  `icon_class` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `created_by`, `active`, `last_modified_by`, `icon_class`) VALUES
(1, 'Programming', 1, 1, 1, NULL),
(2, 'Web', 1, 1, 1, NULL),
(3, 'Design', 1, 0, 1, NULL),
(4, 'Education', 1, 1, 1, NULL),
(5, 'Business', 1, 1, 1, NULL),
(8, 'Note', 1, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `content_id` int(11) NOT NULL,
  `content_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `content_heading` text COLLATE utf8_unicode_ci,
  `content_data` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`content_id`, `content_type`, `content_heading`, `content_data`) VALUES
(1, 'wc_title', '', 'Welcome'),
(2, 'wc_msg', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu urna sit amet libero posuere egestas. Aenean et enim eget dolor fringilla pulvinar. Pellentesque elit libero, placerat et eros id, pretium interdum nibh.'),
(3, 'about_us', 'About MinorSchool', '<div>MinorSchool is the best e-Learning management application available on CodeCanyon. You can create unlimited courses and lessons with easy to use dashboard. The lesson can be video, document, youtube video and external content link. The interesting part is you can link one or more exams to a course, after finishing the course the student can take the linked exam and teacher/admin can view the exam results to monitor the student''s progress. </div><div><br>This LMS system built to manage learning contents very easily and effortlessly. The user interface is designed for nontechnical people. The PayPal payment gateway is integrated to accept payment for premium contents and subscriptions. User experience will great with some very useful modules like Blog, FAQ, Noticeboard and Inbox.<br><br></div>'),
(4, 'price_table_msg', 'Subscribe to Start Learning Now', 'Get access to a huge library of learning material, and support the site that helps you learn.'),
(5, 'slider_text', 'Online Learning made Easy', 'Non stop <b>learning</b> whenever you want wherever you want.'),
(6, 'slider_text', 'MinorSchool.net', 'One of the best<i> E-learning</i> platform available.'),
(7, 'slider_text', 'Enjoy Full Freedom', 'You don''t have to live your comfort zone. Learn ANYTIME from ANYWHERE.');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country_id` smallint(5) UNSIGNED NOT NULL,
  `country_code` char(2) NOT NULL,
  `country_code3` char(3) DEFAULT NULL,
  `country_name` varchar(255) NOT NULL,
  `currency_id` smallint(5) UNSIGNED DEFAULT NULL,
  `timezone_id` smallint(5) UNSIGNED DEFAULT NULL,
  `latitude` float DEFAULT NULL,
  `longitude` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_id`, `country_code`, `country_code3`, `country_name`, `currency_id`, `timezone_id`, `latitude`, `longitude`) VALUES
(1, 'AD', 'AND', 'Andorra', 49, 1, 42.5, 1.5),
(2, 'AE', 'ARE', 'United Arab Emirates', 1, 2, 24, 54),
(3, 'AF', 'AFG', 'Afghanistan', 2, 3, 33, 65),
(4, 'AG', 'ATG', 'Antigua and Barbuda', 168, 4, 17.05, -61.8),
(5, 'AI', 'AIA', 'Anguilla', 168, 5, 18.25, -63.1667),
(6, 'AL', 'ALB', 'Albania', 3, 6, 41, 20),
(7, 'AM', 'ARM', 'Armenia', 4, 7, 40, 45),
(8, 'AO', 'AGO', 'Angola', 6, 8, -12.5, 18.5),
(9, 'AQ', 'ATA', 'Antarctica', NULL, 13, -90, 0),
(10, 'AR', 'ARG', 'Argentina', 7, 19, -34, -64),
(11, 'AS', 'ASM', 'American Samoa', 151, 31, -14.3333, -170),
(12, 'AT', 'AUT', 'Austria', 49, 32, 47.3333, 13.3333),
(13, 'AU', 'AUS', 'Australia', 8, 45, -27, 133),
(14, 'AW', 'ABW', 'Aruba', 9, 46, 12.5, -69.9667),
(15, 'AX', 'ALA', 'Ãƒâ€¦land Islands', 49, 47, 60.177, 19.915),
(16, 'AZ', 'AZE', 'Azerbaijan', 10, 48, 40.5, 47.5),
(17, 'BA', 'BIH', 'Bosnia and Herzegovina', 11, 49, 44, 18),
(18, 'BB', 'BRB', 'Barbados', 12, 50, 13.1667, -59.5333),
(19, 'BD', 'BGD', 'Bangladesh', 13, 51, 24, 90),
(20, 'BE', 'BEL', 'Belgium', 49, 52, 50.8333, 4),
(21, 'BF', 'BFA', 'Burkina Faso', 171, 53, 13, -2),
(22, 'BG', 'BGR', 'Bulgaria', 14, 54, 43, 25),
(23, 'BH', 'BHR', 'Bahrain', 15, 55, 26, 50.55),
(24, 'BI', 'BDI', 'Burundi', 16, 56, -3.5, 30),
(25, 'BJ', 'BEN', 'Benin', 171, 57, 9.5, 2.25),
(26, 'BL', 'BLM', 'Saint BarthÃƒÂ©lemy', 49, 58, 17.9, -62.8333),
(27, 'BM', 'BMU', 'Bermuda', 17, 59, 32.3333, -64.75),
(28, 'BN', 'BRN', 'Brunei', 18, 60, 4.5, 114.667),
(29, 'BO', 'BOL', 'Bolivia', 19, 61, -17, -65),
(30, 'BQ', 'BES', 'Bonaire, Sint Eustatius and Saba', 151, 62, 12.1784, -68.2385),
(31, 'BR', 'BRA', 'Brazil', 21, 78, -10, -55),
(32, 'BS', 'BHS', 'Bahamas', 22, 79, 24.25, -76),
(33, 'BT', 'BTN', 'Bhutan', 23, 80, 27.5, 90.5),
(34, 'BV', 'BVT', 'Bouvet Island', 109, NULL, -54.4333, 3.4),
(35, 'BW', 'BWA', 'Botswana', 24, 81, -22, 24),
(36, 'BY', 'BLR', 'Belarus', 25, 82, 53, 28),
(37, 'BZ', 'BLZ', 'Belize', 26, 83, 17.25, -88.75),
(38, 'CA', 'CAN', 'Canada', 27, 107, 60, -95),
(39, 'CC', 'CCK', 'Cocos Islands', 8, 112, -12.5, 96.8333),
(40, 'CD', 'COD', 'DR Congo', 28, 113, 0, 25),
(41, 'CF', 'CAF', 'Central African Republic', 161, 115, 7, 21),
(42, 'CG', 'COG', 'Congo', 161, 116, -1, 15),
(43, 'CH', 'CHE', 'Switzerland', 29, 117, 47, 8),
(44, 'CI', 'CIV', 'CÃƒÂ´te d''Ivoire', 171, 118, 8, -5),
(45, 'CK', 'COK', 'Cook Islands', 111, 119, -21.2333, -159.767),
(46, 'CL', 'CHL', 'Chile', 32, 427, -30, -71),
(47, 'CM', 'CMR', 'Cameroon', 161, 122, 6, 12),
(48, 'CN', 'CHN', 'China', 34, 126, 35, 105),
(49, 'CO', 'COL', 'Colombia', 35, 128, 4, -72),
(50, 'CR', 'CRI', 'Costa Rica', 37, 129, 10, -84),
(51, 'CU', 'CUB', 'Cuba', 38, 130, 21.5, -80),
(52, 'CV', 'CPV', 'Cape Verde', 40, 131, 16, -24),
(53, 'CW', 'CUW', 'CuraÃƒÂ§ao', 5, 132, 12.1696, -68.99),
(54, 'CX', 'CXR', 'Christmas Island', 8, 133, -10.5, 105.667),
(55, 'CY', 'CYP', 'Cyprus', 49, 134, 35, 33),
(56, 'CZ', 'CZE', 'Czech Republic', 41, 135, 49.75, 15.5),
(57, 'DE', 'DEU', 'Germany', 49, 136, 51, 9),
(58, 'DJ', 'DJI', 'Djibouti', 42, 138, 11.5, 43),
(59, 'DK', 'DNK', 'Denmark', 43, 139, 56, 10),
(60, 'DM', 'DMA', 'Dominica', 168, 140, 15.4167, -61.3333),
(61, 'DO', 'DOM', 'Dominican Republic', 44, 141, 19, -70.6667),
(62, 'DZ', 'DZA', 'Algeria', 45, 142, 28, 3),
(63, 'EC', 'ECU', 'Ecuador', 151, 143, -2, -77.5),
(64, 'EE', 'EST', 'Estonia', 49, 145, 59, 26),
(65, 'EG', 'EGY', 'Egypt', 46, 146, 27, 30),
(66, 'EH', 'ESH', 'Western Sahara', 91, 147, 24.5, -13),
(67, 'ER', 'ERI', 'Eritrea', 47, 148, 15, 39),
(68, 'ES', 'ESP', 'Spain', 49, 151, 40, -4),
(69, 'ET', 'ETH', 'Ethiopia', 48, 152, 8, 38),
(70, 'EU', '', 'European Union', 49, NULL, 47, 8),
(71, 'FI', 'FIN', 'Finland', 49, 153, 64, 26),
(72, 'FJ', 'FJI', 'Fiji', 50, 154, -18, 175),
(73, 'FK', 'FLK', 'Falkland Islands', 51, 155, -51.75, -59),
(74, 'FM', 'FSM', 'Micronesia', 151, 156, 6.9167, 158.25),
(75, 'FO', 'FRO', 'Faroe Islands', 43, 159, 62, -7),
(76, 'FR', 'FRA', 'France', 49, 160, 46, 2),
(77, 'GA', 'GAB', 'Gabon', 161, 161, -1, 11.75),
(78, 'GB', 'GBR', 'United Kingdom', 52, 162, 54, -2),
(79, 'GD', 'GRD', 'Grenada', 168, 163, 12.1167, -61.6667),
(80, 'GE', 'GEO', 'Georgia', 53, 164, 42, 43.5),
(81, 'GF', 'GUF', 'French Guiana', 49, 165, 4, -53),
(82, 'GG', 'GGY', 'Guernsey', 52, 166, 49.4657, -2.58528),
(83, 'GH', 'GHA', 'Ghana', 54, 167, 8, -2),
(84, 'GI', 'GIB', 'Gibraltar', 55, 168, 36.1833, -5.3667),
(85, 'GL', 'GRL', 'Greenland', 43, 170, 72, -40),
(86, 'GM', 'GMB', 'Gambia', 56, 173, 13.4667, -16.5667),
(87, 'GN', 'GIN', 'Guinea', 57, 174, 11, -10),
(88, 'GP', 'GLP', 'Guadeloupe', 49, 175, 16.25, -61.5833),
(89, 'GQ', 'GNQ', 'Equatorial Guinea', 161, 176, 2, 10),
(90, 'GR', 'GRC', 'Greece', 49, 177, 39, 22),
(91, 'GS', 'SGS', 'South Georgia and the South Sandwich Islands', NULL, 178, -54.5, -37),
(92, 'GT', 'GTM', 'Guatemala', 58, 179, 15.5, -90.25),
(93, 'GU', 'GUM', 'Guam', 151, 180, 13.4667, 144.783),
(94, 'GW', 'GNB', 'Guinea-Bissau', 171, 181, 12, -15),
(95, 'GY', 'GUY', 'Guyana', 59, 182, 5, -59),
(96, 'HK', 'HKG', 'Hong Kong', 60, 183, 22.25, 114.167),
(97, 'HM', 'HMD', 'Heard Island and McDonald Islands', 8, NULL, -53.1, 72.5167),
(98, 'HN', 'HND', 'Honduras', 61, 184, 15, -86.5),
(99, 'HR', 'HRV', 'Croatia', 62, 185, 45.1667, 15.5),
(100, 'HT', 'HTI', 'Haiti', 63, 186, 19, -72.4167),
(101, 'HU', 'HUN', 'Hungary', 64, 187, 47, 20),
(102, 'ID', 'IDN', 'Indonesia', 65, 188, -5, 120),
(103, 'IE', 'IRL', 'Ireland', 49, 192, 53, -8),
(104, 'IL', 'ISR', 'Israel', 66, 193, 31.5, 34.75),
(105, 'IM', 'IMN', 'Isle of Man', 52, 194, 54.2361, -4.54806),
(106, 'IN', 'IND', 'India', 67, 195, 20, 77),
(107, 'IO', 'IOT', 'British Indian Ocean Territory', 151, 196, -6, 71.5),
(108, 'IQ', 'IRQ', 'Iraq', 68, 197, 33, 44),
(109, 'IR', 'IRN', 'Iran', 69, 198, 32, 53),
(110, 'IS', 'ISL', 'Iceland', 70, 199, 65, -18),
(111, 'IT', 'ITA', 'Italy', 49, 200, 42.8333, 12.8333),
(112, 'JE', 'JEY', 'Jersey', 52, 201, 49.2138, -2.13577),
(113, 'JM', 'JAM', 'Jamaica', 71, 202, 18.25, -77.5),
(114, 'JO', 'JOR', 'Jordan', 72, 203, 31, 36),
(115, 'JP', 'JPN', 'Japan', 73, 204, 36, 138),
(116, 'KE', 'KEN', 'Kenya', 74, 205, 1, 38),
(117, 'KG', 'KGZ', 'Kyrgyzstan', 75, 206, 41, 75),
(118, 'KH', 'KHM', 'Cambodia', 76, 207, 13, 105),
(119, 'KI', 'KIR', 'Kiribati', 8, 210, 1.4167, 173),
(120, 'KM', 'COM', 'Comoros', 77, 211, -12.1667, 44.25),
(121, 'KN', 'KNA', 'Saint Kitts and Nevis', 168, 212, 17.3333, -62.75),
(122, 'KP', 'PRK', 'North Korea', 78, 213, 40, 127),
(123, 'KR', 'KOR', 'South Korea', 79, 214, 37, 127.5),
(124, 'KW', 'KWT', 'Kuwait', 80, 215, 29.3375, 47.6581),
(125, 'KY', 'CYM', 'Cayman Islands', 81, 216, 19.5, -80.5),
(126, 'KZ', 'KAZ', 'Kazakhstan', 82, 217, 48, 68),
(127, 'LA', 'LAO', 'Laos', 83, 222, 18, 105),
(128, 'LB', 'LBN', 'Lebanon', 84, 223, 33.8333, 35.8333),
(129, 'LC', 'LCA', 'Saint Lucia', 168, 224, 13.8833, -61.1333),
(130, 'LI', 'LIE', 'Liechtenstein', 30, 225, 47.1667, 9.5333),
(131, 'LK', 'LKA', 'Sri Lanka', 85, 226, 7, 81),
(132, 'LR', 'LBR', 'Liberia', 86, 227, 6.5, -9.5),
(133, 'LS', 'LSO', 'Lesotho', 87, 228, -29.5, 28.5),
(134, 'LT', 'LTU', 'Lithuania', 88, 229, 56, 24),
(135, 'LU', 'LUX', 'Luxembourg', 49, 230, 49.75, 6.1667),
(136, 'LV', 'LVA', 'Latvia', 89, 231, 57, 25),
(137, 'LY', 'LBY', 'Libya', 90, 232, 25, 17),
(138, 'MA', 'MAR', 'Morocco', 91, 233, 32, -5),
(139, 'MC', 'MCO', 'Monaco', 49, 234, 43.7333, 7.4),
(140, 'MD', 'MDA', 'Moldova', 92, 235, 47, 29),
(141, 'ME', 'MNE', 'Montenegro', 49, 236, 42, 19),
(142, 'MF', 'MAF', 'Saint Martin', 49, 237, 18.0525, -63.0737),
(143, 'MG', 'MDG', 'Madagascar', 93, 238, -20, 47),
(144, 'MH', 'MHL', 'Marshall Islands', 151, 240, 9, 168),
(145, 'MK', 'MKD', 'Macedonia', 94, 241, 41.8333, 22),
(146, 'ML', 'MLI', 'Mali', 171, 242, 17, -4),
(147, 'MM', 'MMR', 'Myanmar', 95, 243, 22, 98),
(148, 'MN', 'MNG', 'Mongolia', 96, 244, 46, 105),
(149, 'MO', 'MAC', 'Macao', 97, 247, 22.1667, 113.55),
(150, 'MP', 'MNP', 'Northern Mariana Islands', 151, 248, 15.2, 145.75),
(151, 'MQ', 'MTQ', 'Martinique', 49, 249, 14.6667, -61),
(152, 'MR', 'MRT', 'Mauritania', 98, 250, 20, -12),
(153, 'MS', 'MSR', 'Montserrat', 168, 251, 16.75, -62.2),
(154, 'MT', 'MLT', 'Malta', 49, 252, 35.8333, 14.5833),
(155, 'MU', 'MUS', 'Mauritius', 99, 253, -20.2833, 57.55),
(156, 'MV', 'MDV', 'Maldives', 100, 254, 3.25, 73),
(157, 'MW', 'MWI', 'Malawi', 101, 255, -13.5, 34),
(158, 'MX', 'MEX', 'Mexico', 102, 263, 23, -102),
(159, 'MY', 'MYS', 'Malaysia', 104, 268, 2.5, 112.5),
(160, 'MZ', 'MOZ', 'Mozambique', 105, 270, -18.25, 35),
(161, 'NA', 'NAM', 'Namibia', 106, 271, -22, 17),
(162, 'NC', 'NCL', 'New Caledonia', 173, 272, -21.5, 165.5),
(163, 'NE', 'NER', 'Niger', 171, 273, 16, 8),
(164, 'NF', 'NFK', 'Norfolk Island', 8, 274, -29.0333, 167.95),
(165, 'NG', 'NGA', 'Nigeria', 107, 275, 10, 8),
(166, 'NI', 'NIC', 'Nicaragua', 108, 276, 13, -85),
(167, 'NL', 'NLD', 'Netherlands', 49, 277, 52.5, 5.75),
(168, 'NO', 'NOR', 'Norway', 109, 278, 62, 10),
(169, 'NP', 'NPL', 'Nepal', 110, 279, 28, 84),
(170, 'NR', 'NRU', 'Nauru', 8, 280, -0.5333, 166.917),
(171, 'NU', 'NIU', 'Niue', 111, 281, -19.0333, -169.867),
(172, 'NZ', 'NZL', 'New Zealand', 111, 282, -41, 174),
(173, 'OM', 'OMN', 'Oman', 112, 284, 21, 57),
(174, 'PA', 'PAN', 'Panama', 113, 285, 9, -80),
(175, 'PE', 'PER', 'Peru', 114, 286, -10, -76),
(176, 'PF', 'PYF', 'French Polynesia', 173, 288, -15, -140),
(177, 'PG', 'PNG', 'Papua New Guinea', 115, 290, -6, 147),
(178, 'PH', 'PHL', 'Philippines', 116, 291, 13, 122),
(179, 'PK', 'PAK', 'Pakistan', 117, 292, 30, 70),
(180, 'PL', 'POL', 'Poland', 118, 293, 52, 20),
(181, 'PM', 'SPM', 'Saint Pierre and Miquelon', 49, 294, 46.8333, -56.3333),
(182, 'PN', 'PCN', 'Pitcairn', 111, 295, -24.7036, -127.439),
(183, 'PR', 'PRI', 'Puerto Rico', 151, 296, 18.25, -66.5),
(184, 'PS', 'PSE', 'Palestine', NULL, 297, 32, 35.25),
(185, 'PT', 'PRT', 'Portugal', 49, 301, 39.5, -8),
(186, 'PW', 'PLW', 'Palau', 151, 302, 7.5, 134.5),
(187, 'PY', 'PRY', 'Paraguay', 119, 303, -23, -58),
(188, 'QA', 'QAT', 'Qatar', 120, 304, 25.5, 51.25),
(189, 'RE', 'REU', 'RÃƒÂ©union', 49, 305, -21.1, 55.6),
(190, 'RO', 'ROU', 'Romania', 121, 306, 46, 25),
(191, 'RS', 'SRB', 'Serbia', 122, 307, 44, 21),
(192, 'RU', 'RUS', 'Russia', 123, 323, 60, 100),
(193, 'RW', 'RWA', 'Rwanda', 124, 326, -2, 30),
(194, 'SA', 'SAU', 'Saudi Arabia', 125, 327, 25, 45),
(195, 'SB', 'SLB', 'Solomon Islands', 126, 328, -8, 159),
(196, 'SC', 'SYC', 'Seychelles', 127, 329, -4.5833, 55.6667),
(197, 'SD', 'SDN', 'Sudan', 128, 330, 15, 30),
(198, 'SE', 'SWE', 'Sweden', 129, 331, 62, 15),
(199, 'SG', 'SGP', 'Singapore', 130, 332, 1.3667, 103.8),
(200, 'SH', 'SHN', 'Saint Helena, Ascension and Tristan da Cunha', 131, 333, -15.9333, -5.7),
(201, 'SI', 'SVN', 'Slovenia', 49, 334, 46, 15),
(202, 'SJ', 'SJM', 'Svalbard and Jan Mayen', 109, 335, 78, 20),
(203, 'SK', 'SVK', 'Slovakia', 49, 336, 48.6667, 19.5),
(204, 'SL', 'SLE', 'Sierra Leone', 132, 337, 8.5, -11.5),
(205, 'SM', 'SMR', 'San Marino', 49, 338, 43.9333, 12.4667),
(206, 'SN', 'SEN', 'Senegal', 171, 339, 14, -14),
(207, 'SO', 'SOM', 'Somalia', 133, 340, 10, 49),
(208, 'SR', 'SUR', 'Suriname', 134, 341, 4, -56),
(209, 'SS', 'SSD', 'South Sudan', 135, 342, 7.96309, 30.1589),
(210, 'ST', 'STP', 'Sao Tome and Principe', 136, 343, 1, 7),
(211, 'SV', 'SLV', 'El Salvador', 151, 344, 13.8333, -88.9167),
(212, 'SX', 'SXM', 'Sint Maarten', 5, 345, 18.0273, -63.0501),
(213, 'SY', 'SYR', 'Syrian Arab Republic', 138, 346, 35, 38),
(214, 'SZ', 'SWZ', 'Swaziland', 139, 347, -26.5, 31.5),
(215, 'TC', 'TCA', 'Turks and Caicos Islands', 151, 348, 21.75, -71.5833),
(216, 'TD', 'TCD', 'Chad', 161, 349, 15, 19),
(217, 'TF', 'ATF', 'French Southern Territories', 49, 350, -43, 67),
(218, 'TG', 'TGO', 'Togo', 171, 351, 8, 1.1667),
(219, 'TH', 'THA', 'Thailand', 140, 352, 15, 100),
(220, 'TJ', 'TJK', 'Tajikistan', 141, 353, 39, 71),
(221, 'TK', 'TKL', 'Tokelau', 111, 354, -9, -172),
(222, 'TL', 'TLS', 'Timor-Leste', 151, 355, -8.87422, 125.728),
(223, 'TM', 'TKM', 'Turkmenistan', 142, 356, 40, 60),
(224, 'TN', 'TUN', 'Tunisia', 143, 357, 34, 9),
(225, 'TO', 'TON', 'Tonga', 144, 358, -20, -175),
(226, 'TR', 'TUR', 'Turkey', 145, 359, 39, 35),
(227, 'TT', 'TTO', 'Trinidad and Tobago', 146, 360, 11, -61),
(228, 'TV', 'TUV', 'Tuvalu', 8, 361, -8, 178),
(229, 'TW', 'TWN', 'Taiwan', 147, 362, 23.5, 121),
(230, 'TZ', 'TZA', 'Tanzania', 148, 363, -6, 35),
(231, 'UA', 'UKR', 'Ukraine', 149, 364, 49, 32),
(232, 'UG', 'UGA', 'Uganda', 150, 368, 1, 32),
(233, 'UM', 'UMI', 'U.S. Minor Outlying Islands', 151, NULL, 19.2833, 166.6),
(234, 'US', 'USA', 'United States', 151, 392, 38, -97),
(235, 'UY', 'URY', 'Uruguay', 155, 402, -33, -56),
(236, 'UZ', 'UZB', 'Uzbekistan', 156, 404, 41, 64),
(237, 'VA', 'VAT', 'Vatican City', 49, 405, 41.9, 12.45),
(238, 'VC', 'VCT', 'Saint Vincent and the Grenadines', 168, 406, 13.25, -61.2),
(239, 'VE', 'VEN', 'Venezuela', 157, 407, 8, -66),
(240, 'VG', 'VGB', 'British Virgin Islands', 151, 408, 18.5, -64.5),
(241, 'VI', 'VIR', 'U.S. Virgin Islands', 151, 409, 18.3333, -64.8333),
(242, 'VN', 'VNM', 'Vietnam', 158, 410, 16, 106),
(243, 'VU', 'VUT', 'Vanuatu', 159, 411, -16, 167),
(244, 'WF', 'WLF', 'Wallis and Futuna', 173, 412, -13.3, -176.2),
(245, 'WS', 'WSM', 'Samoa', 160, 413, -13.5833, -172.333),
(246, 'YE', 'YEM', 'Yemen', 179, 414, 15, 48),
(247, 'YT', 'MYT', 'Mayotte', 49, 415, -12.8333, 45.1667),
(248, 'ZA', 'ZAF', 'South Africa', 180, 416, -29, 24),
(249, 'ZM', 'ZMB', 'Zambia', 181, 417, -15, 30),
(250, 'ZW', 'ZWE', 'Zimbabwe', 182, 418, -20, 30);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_title` text COLLATE utf8_unicode_ci NOT NULL,
  `course_intro` text COLLATE utf8_unicode_ci,
  `course_description` text COLLATE utf8_unicode_ci,
  `course_price` float DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `course_requirement` text COLLATE utf8_unicode_ci,
  `target_audience` text COLLATE utf8_unicode_ci,
  `what_i_get` text COLLATE utf8_unicode_ci,
  `course_count_reviews` int(11) DEFAULT NULL,
  `course_rating` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  `course_view_count` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_title`, `course_intro`, `course_description`, `course_price`, `category_id`, `course_requirement`, `target_audience`, `what_i_get`, `course_count_reviews`, `course_rating`, `course_view_count`, `created_by`, `active`) VALUES
(1, 'Basic Typography', 'Learn how to do stunning dynamic typography &nbsp;in Photoshop and Illustrator!', 'Welcome to my first Typographic Course on Minor School!&nbsp;In this Course, I will show you the complete typographic process from the beginning till the end. In this &nbsp;course you will get knowledge to create your own breathtaking typography!&nbsp;No matter if you just started your adventure with photoshop or you have knowledge about photoshop. This course is slowly and well explained, so even beginners can find a way to create their own projects with&nbsp;this course.', 15, 1, '<div><ul><li>You need to have Adobe Photoshop and Adobe Illustrator</li></ul></div><div></div>', '<div><ul><li>Beginners which has basic knowlege about tools in Photoshop and wants to go into Typography</li><li>People Who want to start their adventure with Typography</li><li>Users who wants to improve skills in Typography</li></ul></div><div></div>', 'You will learn the basic knowledge about Typography. After completing this course you can do dynamic Typography by using Adobe&nbsp;&nbsp;Photoshop or Adobe Illustrator.', 0, '', 0, 1, 1),
(2, 'Sketch for better Design?', 'Learn How to do Sketch in Adobe Photoshop', 'This course&nbsp;will learn you about &nbsp;the&nbsp;mobile application design by providing the assets files&nbsp;&nbsp;with only a few hours of training. This course will teach you to do the Sketch &nbsp;to create &nbsp;dynamic design&nbsp;that impress clients and engage users.', 20, 2, 'Must have basic knowledge of Adobe Photoshop and also have this software in your PC.', '<ul><li>This course is perfect for web and print designers</li><li>This course is perfect for Photoshop or Illustrator users</li><li>This course requires practically no prior design experience</li><li>Some graphic design experience will be helpful</li></ul>', 'Since without Sketch it''s almost impossible create a dynamic design. So you''ll learn to sketch by this design and the door of creating good design will open for you.', 0, '', 0, 1, 1),
(3, 'Basic Rules of Illustration', 'Basic Rules of Illustration', 'Design your own Character Illustration using Adobe Illustrator CC.&nbsp;This course will show you how to take just a few simple tools and create a high-quality &amp; professional product that you can use to promote yourself online.', 10, 3, '<ul><li>Sketch Pad, Paper, or something to draw on</li><li>You will need basic to intermediate drawing capability. This course will show you how to digitally illustrate a sketch that you make on your own, but you will need to make a sketch on your own first.</li><li>Pencil</li></ul>', '<div><ul><li>Anyone Who Wants to Create Fun &amp; Simple Character Digital Illustrations</li><li>This course isn''t for those that don''t enjoy learning new software</li></ul></div>', '<ul><li>Over 14 lectures and 1.5 hours of content!</li><li>Learn the Basics of Adobe Illustrator CC</li><li>Develop Concept Sketches &amp; Turn It Into A Digital Illustration</li></ul>', 0, '', 0, 1, 1),
(4, 'How to Color', 'How to Color in a Stunning Way', '"This is a masterpiece of how to balance your life in colors and chakras. it is packed full of useful information for everyday life and how it all connects to your spiritual evolution as well. Cha~zay really shows her deep knowledge of metaphysics in a way anyone can understand and use."', 0, 4, '<div><ul><li>This course requires no previous skills - all are welcome</li></ul></div>', '<div><ul><li>This course is for business executives, consultants, business owners, employees, coaches and healers</li><li>This course is for anyone who is interested in personal development and how to influence your own world with the power of colors</li></ul></div>', '<ul><li>Discern which colors set them up for success and which ones set them up for failure</li><li>Know exactly which colors to use in your bedroom or office</li><li>Which colors attract and which ones repel, depending on what your motive is</li><li>What changes to your website to reach a 20-60% conversion boost</li><li>What colors to choose intimidate people and which ones to wear to generate a peaceful aura around you</li></ul>', 0, '', 0, 1, 1),
(5, 'Communication', 'How Communicate in smart and confident&nbsp;way?', 'Communication is a critical skill for almost everything we do. Whether you''re speaking to another person, addressing a group or even giving a formal presentation, confident communicators will often enjoy more fulfilling relationships with others.', 200, 5, '<div><ul><li>Students are asked to write down an associated action, for each point made - so a notebook and pen will be required.</li><li>If you are going to become an effective communicator then it will mean you’ll have to change the way you behave and interact with others, so a willingness to action new information is required.</li></ul></div>', '<ul><li>Individual contributors, Managers, Team leaders, whose success depends on their ability to communicate clearly, to be understood and to influence how another person performs, and create positive working relationships.</li></ul>', '<ul><li>Communicate a message in a way that is clear, concise and embraced by others.</li><li>Fully understand and connect with other people in more effective ways.</li><li>Transfer your ideas, information and emotions into the minds of others, without any errors.</li></ul>', 0, '', 0, 1, 1),
(6, 'Leadership Skills Mastery', 'How to Become a Leader and Increase Your Influence, Loyalty &amp; Income', 'Some people believe that you either born with leadership skills and leadership qualities, or your not.The good news is that leadership skills can be learned and practiced, which means you can can increase your leadership abilities.', 150, 6, '<div><ul><li>An Open Mind</li><li>Internet Access</li><li>Willingness to Apply What is Learned</li></ul></div>', '<div><ul><li>This course is primarily for beginning and intermediate level leaders</li><li>This course is also for experienced Leaders who are not getting the results they are looking for</li><li>This course is not for veteran Leaders who are happy with their results</li></ul></div>', '<ul><li>Rapidly Build Trust &amp; Establish Lasting Loyalty with Your Followers</li><li>Develop a Compelling &amp; Crystal Clear Leadership Vision</li><li>Make Better Decisions &amp; Save Time by Learning to Think Like a Real Leader</li><li>Think, Communicate &amp; Behave Like a World Class Leader</li></ul>', 0, '', 0, 1, 1),
(7, 'Productivity Hacks', 'Learn the EXACT hacks to make more money &amp; save hours every day. Easy strategies you can get real results from today!', 'Let''s be honest, most "productivity hacks" just don''t work. We start them with the best intentions, but along the way we get distracted or discouraged.', 0, 7, '<div><ul><li>Computer (Mac preferred but most apps work on Mac &amp; Windows)</li><li>A few minutes a day to learn and something to take notes with!</li></ul></div>', '<ul><li>Entrepreneurs</li><li>Small Businesses</li><li>Managers</li><li>Marketers &amp; Salespeople</li></ul>', '<ul><li>By the end of this course, you''ll know exactly where your time goes each day.</li><li>You''ll learn how to take the first steps in growing your business with systems</li><li>You''ll learn how to delegate your weaknesses. Learn from experts how to outsource the work you shouldn''t be doing.</li></ul>', 0, '', 0, 1, 1),
(8, 'Management Skills', 'Learn how to better communicate with and motivate others like an expert.', 'For less money than what many people will spend eating out lunch for a week, you can be exposed tocommunication skills and motivational tactics that have been presented and delivered to over 100,000 people worldwide.', 200, 8, '<div><ul><li>Students do not need to prepare for anything in advance of starting the course.</li></ul></div>', '<ul><li>This course is about communication and motivation of others. Therefore it should have a wide appeal of anyone looking to increase their skills in those areas.</li><li>Managers will find information that will help them throughout their career.</li></ul>', '<ul><li>At the end of the course, students will be able to identify personal traits as well as traits of others that could improve their ability to communicate and motivate effectively.</li><li>Students will be able to identify personal habits both good and bad they need to be strengthened or eliminated.</li></ul>', 0, '', 0, 1, 1),
(9, 'The Ultimate Web Development Course', 'Learn ALL the major web development technologies in one working project: HTML, CSS, MySQL, PHP, jQuery and AJAX.', 'This has been one of the best web courses ever. It should be used as a model by almost anyone thinking of teaching on the web. It has cleared out nearly a decade of web programming cobwebs. The fact you have made a course which is complete end-to-end is impressive.&nbsp;', 250, 9, '<div><ul><li>A computer connected to the internet</li><li>The ability/permission to download software</li><li>A text editor (I recommend Komodo Edit, which is free)</li><li>Enthusiasm!</li></ul></div>', '<div><ul><li>Anyone interested in web design and development</li><li>No prior knowledge needed</li></ul></div>', '<ul><li>Flexible course design allows for complete beginners or more advanced learners</li><li>Learn HTML5, CSS, MySQL, PHP, jQuery and AJAX in one working project</li><li>Up-to-date coding standards using mysqli and prepared statements to ensure database security</li><li>Instant update website - the most modern web interface</li></ul>', 0, '', 0, 1, 1),
(10, 'Programming Language for Begginers', 'Unlock your super hero skills to master the C programming language in less than 30 days guaranteed.', 'In this course, we''ll explore the C programming language in a different way than is usually taught.', 200, 10, '<div><ul><li>Any Programming Knowledge is Preferable, but not Compulsory.</li></ul></div>', '<div><ul><li>Freshers wants to learn C Programming Language</li><li>Those who Learned C Programming but now want to Brush up their Skills</li></ul></div>', '<div><ul><li>Understand Pointers in a better way</li><li>Write Command Line Arguments</li><li>Write a Program using C Language</li></ul></div>', 0, '', 0, 1, 1),
(11, 'Building Desktop Apps', 'Learn the basics about WPF app creation, such as XAML, C#, Data Binding, Animations, creating User Controls and MVVM.', 'Make money creating desktop apps and User Controls!Desktop apps are still a very important request from big companies, and in this course you will find what you need to start creating those companies'' apps!', 20, 11, '<div><ul><li>Visual Studio 2013 (Express for Windows Desktop is fine) Installed</li><li>Blend for Visual Studio installed (installs with Visual Studio)</li></ul></div>', '<div><ul><li>This WPF course is for newbies, altough prior programming knowledge is required. If you want to kickstart your desktop app building knowledge this course is the course for you. If you are looking for advanced WPF knowledge, this course is probably NOT for you.</li></ul></div>', '<div><ul><li>Build custom user controls.</li><li>Use the best practices, such as Data Binding.</li><li>Create animations for use inside an app.</li><li>Learn a design pattern (MVVM)</li></ul></div>', 0, '', 0, 1, 1),
(12, 'Create Mobile Apps', 'Learn to build cross-platform iOS and Android apps in HTML/CSS/JavaScript with Ionic Framework, AngularJS and Cordova.', 'Learn&nbsp;Ionic, the best way currently available to&nbsp;develop mobile apps in HTML5.&nbsp;Covers Ionic v1.0/1.1. Last updated: December 2015.', 20, 12, '<ul><li>Computer running Windows, Mac, or Linux (Mac needed to package iOS apps)</li><li>Knowledge of HTML, CSS, and JavaScript</li><li>Knowledge of AngularJS advantageous but not essential</li></ul>', '<div><ul><li>Web developers that want to build mobile apps</li></ul></div>', '<div><ul><li>Develop complete mobile apps in HTML5</li><li>Use the Ionic CSS and JavaScript Components</li><li>Use Cordova plugins to access native APIs (e.g. Camera)</li><li>Build and run your apps in Android and iOS</li></ul></div>', 0, '', 0, 1, 1),
(13, 'TESRTTT', 'fdsfsdf', 'fdsfsdf', 0, 13, 'fdsfsdfsdf', 'dfsdfsdf', 'fsdfsdfsdf', NULL, '', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `course_sections`
--

CREATE TABLE `course_sections` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT '',
  `section_title` text COLLATE utf8_unicode_ci,
  `course_id` int(11) DEFAULT NULL,
  `video_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doc_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `audio_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ppt_ids` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `orderList` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `course_sections`
--

INSERT INTO `course_sections` (`section_id`, `section_name`, `section_title`, `course_id`, `video_ids`, `doc_ids`, `audio_ids`, `ppt_ids`, `orderList`) VALUES
(1, 'SECTION 1', 'Introduction', 1, '1,12,13,15,20', '', '', '', 0),
(2, 'SECTION 2', 'Basic Knowledge of Typography', 1, '2,3,6,14', '', '', '', 1),
(3, 'SECTION 3', 'Why Make Custom Lettering?', 1, '4,5', '', '', '', 3),
(4, 'SECTION 4', 'Examples of Type and Lettering Design', 1, '', '', '', '', 2),
(5, 'SECTION 5', 'Conclusion', 1, '', '', '', '', 4),
(6, 'SECTION 1', 'Introduction', 2, '7', '', '', '', 0),
(7, 'SECTION 2', 'Basic', 2, '', '', '', '', 0),
(8, 'SECTION 3', 'Intermediate&nbsp;', 2, '', '', '', '', 0),
(9, 'SECTION 4', 'Advanced', 2, '8', '', '', '', 0),
(10, 'SECTION 1', 'Things to know before we start ', 3, '10,11,19', '', '', '', 0),
(11, 'SECTION 2', 'Basics', 3, '16,17,18', '', '', '', 0),
(12, 'SECTION 1', 'Basic', 12, '9', '', '', '', 0),
(13, 'SECTION 1', 'Setup', 12, '', '', '', '', 0),
(14, 'SECTION 1', 'Introduction&nbsp;', 11, '', '', '', '', 0),
(15, 'SECTION 2', 'Basic', 11, '', '', '', '', 0),
(16, 'SECTION 1', 'Bootstraping', 4, '21', '', '', '', 0),
(17, 'SECTION 2', 'Basic', 4, '22', '', '', '', 0),
(18, 'SECTION 1', 'Intermediate', 4, NULL, NULL, NULL, NULL, 0),
(19, 'SECTION 2', 'Advanced', 4, NULL, NULL, NULL, NULL, 0),
(20, 'SECTION 3', 'What''s Next', 4, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `course_videos`
--

CREATE TABLE `course_videos` (
  `video_id` int(20) NOT NULL,
  `course_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `video_title` text COLLATE utf8_unicode_ci,
  `preview_type` text COLLATE utf8_unicode_ci,
  `content_type` text COLLATE utf8_unicode_ci,
  `video_link` text COLLATE utf8_unicode_ci,
  `youtube_link` text COLLATE utf8_unicode_ci,
  `file_size` int(100) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `orderList` int(5) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `course_videos`
--

INSERT INTO `course_videos` (`video_id`, `course_id`, `section_id`, `video_title`, `preview_type`, `content_type`, `video_link`, `youtube_link`, `file_size`, `uploaded_by`, `orderList`) VALUES
(2, 1, 2, 'Kinetic Typography After Effects [motion graphics]', '0', '', '2_Kinetic_Typography_After_Effects_[motion_graphics].mp4', '', 0, NULL, 0),
(3, 1, 2, 'Typography Assignment', NULL, '', '2_Typography_Assignment.mp4', '', 0, NULL, 0),
(4, 1, 3, 'A lesson on typography', '0', '', '3_A_lesson_on_typography.mp4', '', 0, NULL, 0),
(5, 1, 3, 'Motion graphics', '0', '', '3_Motion_graphics.mp4', '', 0, NULL, 0),
(6, 1, 2, 'What''s We Building In There', '0', '', '2_Whats_We_Building_In_There.mp4', '', 0, NULL, 0),
(7, 2, 6, 'Intro', NULL, '', '6_Intro.mp4', '', 0, NULL, 0),
(8, 2, 9, 'Want to know more?', '0', '', '9_Want_to_know_more.mp4', '', 0, NULL, 0),
(9, 12, 12, 'Bootstrapping', NULL, '', '12_Bootstrapping.mp4', '', 0, NULL, 0),
(10, 3, 10, 'web developer salary', NULL, '', '10_web_developer_salary.mp4', '', 0, NULL, 0),
(11, 3, 10, 'Should I Learn Java for Web Development', NULL, '', '10_Should_I_Learn_Java_for_Web_Development.mp4', '', 0, NULL, 0),
(12, 1, 1, 'Test link', 'free', 'external_link', '', 'https://laravel.com/docs/5.2/providers', 0, NULL, 1),
(14, 1, 2, 'TEst B', '0', 'external_link', '', 'http://minorschool_pro.dev/course/course_summary/1', 0, NULL, 0),
(15, 1, 1, 'You tube test', 'free', 'youtube', '', 'https://www.youtube.com/watch?v=GEQhDeNyM8s', 0, NULL, 2),
(16, 3, 11, 'modi new', NULL, 'video', '11_new.mp4', NULL, 0, NULL, 0),
(17, 3, 11, 'file', NULL, 'file', '1400 words SEO.docx', NULL, 0, NULL, 0),
(19, 3, 10, 'Study', NULL, 'external_link', '', 'http://minorschool.dev/index.php/course/add_content/3#', 0, 1, 0),
(20, 1, 1, 'Introduction', 'free', 'video', '1_Introduction.mp4', NULL, 7390549, 1, 0),
(21, 4, 16, 'Introduction to color', NULL, 'video', '16_Introduction_to_color.mp4', NULL, 7390549, 1, 0),
(22, 4, 17, 'Color theory', NULL, 'external_link', '', 'https://en.wikipedia.org/wiki/Color_theory', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `currency_id` smallint(5) UNSIGNED NOT NULL,
  `currency_code` char(3) DEFAULT '',
  `currency_name` varchar(255) DEFAULT '',
  `currency_symbol` varchar(255) DEFAULT NULL,
  `country_id` smallint(5) UNSIGNED DEFAULT NULL,
  `allow_dec` int(1) DEFAULT '1' COMMENT '0= Decimal not allowed'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`currency_id`, `currency_code`, `currency_name`, `currency_symbol`, `country_id`, `allow_dec`) VALUES
(8, 'AUD', 'Australian Dollar', '$', 13, 1),
(27, 'CAD', 'Canadian Dollar', '$', 38, 1),
(183, 'ILS', 'Israeli New Sheqel', '&#8362;', NULL, 1),
(30, 'CHF', 'Swiss Franc', '&#8355;', 43, 1),
(43, 'DKK', 'Danish Krone', 'kr', 59, 1),
(49, 'EUR', 'Euro', '&euro;', 70, 1),
(60, 'HKD', 'Hong Kong Dollar', '$', 96, 1),
(111, 'NZD', 'New Zealand Dollar', '$', 172, 1),
(116, 'PHP', 'Philippine Peso', '&#8369;', 178, 1),
(123, 'RUB', 'Russian Ruble', '&#x584;', 192, 1),
(129, 'SEK', 'Swedish Krona', 'kr', 198, 1),
(130, 'SGD', 'Singapore Dollar', '$', 199, 1),
(151, 'USD', 'US Dollar', '$', 234, 1),
(52, 'GBP', 'Pound Sterling', '&pound;', 78, 1),
(18, 'BRL', 'Brazilian Real', 'R$', 31, 1),
(41, 'CZK', 'Czech Koruna', 'Kč', 56, 1),
(1000, 'JPY', 'Japanese Yen', '¥', NULL, 1),
(104, 'MYR', 'Malaysian Ringgit', 'RM', 159, 1),
(102, 'MXN', 'Mexican Peso', '$', 158, 1),
(1001, 'TWD', 'Taiwan New Dollar', 'NT$', NULL, 1),
(106, 'INR', 'Indian Rupee', '₹', 106, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_title`
--

CREATE TABLE `exam_title` (
  `title_id` int(5) NOT NULL,
  `title_name` text COLLATE utf8_unicode_ci NOT NULL,
  `exam_price` float DEFAULT '0',
  `syllabus` text COLLATE utf8_unicode_ci,
  `random_ques_no` int(5) DEFAULT NULL,
  `pass_mark` int(3) DEFAULT '50' COMMENT '%',
  `time_duration` time DEFAULT '00:02:00',
  `user_id` int(5) DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `active` int(1) DEFAULT '1' COMMENT '1 = active, 0 = inactive',
  `course_id` int(11) DEFAULT NULL,
  `public` tinyint(1) DEFAULT '1',
  `exam_created` datetime DEFAULT NULL,
  `last_modified_by` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `exam_title`
--

INSERT INTO `exam_title` (`title_id`, `title_name`, `exam_price`, `syllabus`, `random_ques_no`, `pass_mark`, `time_duration`, `user_id`, `category_id`, `active`, `course_id`, `public`, `exam_created`, `last_modified_by`) VALUES
(2, 'Color Testing Exam', 0, 'Introduction to Conclusion', 0, 80, '00:20:00', 1, 4, 1, 4, 1, '2017-03-20 16:32:51', 1),
(3, 'Exam on&nbsp;Communication Skills', 0, 'Welcome to Ending', 10, 80, '00:20:00', 1, 5, 1, 0, 1, '2016-01-06 13:39:10', 1),
(6, 'The Complete Web Development', 50, 'Introduction to Conclusion', 7, 80, '00:20:00', 1, 9, 1, NULL, 1, '2016-12-16 03:15:33', 1),
(5, 'Management Skills Exam', 50, 'Welcome to Ending Conversation', 11, 80, '00:30:00', 1, 8, 1, 0, 1, '2016-01-06 13:39:24', 1),
(10, 'teachers exam', 0, 'test', 0, 60, '00:20:00', 4, 5, 1, NULL, 1, '2017-01-22 02:40:02', 4),
(11, 'Test exam', 0, 'All', 0, 60, '00:20:00', 1, 6, 1, 1, 1, '2017-03-18 02:23:50', 1),
(12, 'Basic C', 0, 'cdcdscdsc', 0, 60, '00:20:00', 3, 14, 1, 3, 1, '2017-03-20 00:56:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `faq_id` int(5) NOT NULL,
  `faq_ques` text CHARACTER SET utf8,
  `faq_ans` text CHARACTER SET utf8,
  `faq_created_by` int(5) DEFAULT NULL,
  `faq_last_modified_by` int(5) DEFAULT NULL,
  `faq_last_update` date DEFAULT NULL,
  `faq_grp_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`faq_id`, `faq_ques`, `faq_ans`, `faq_created_by`, `faq_last_modified_by`, `faq_last_update`, `faq_grp_id`) VALUES
(1, 'What are licenses and where can I learn about them?', 'When you ''purchase'' an item from one of our Marketplaces, you''re actually purchasing a license to use that item. Some items have several options for licenses, depending on what you plan to do with the item.&nbsp;All the information on our licenses, including an overview, FAQs, and complete licensing terms can be found on the&nbsp;<a href="http://themeforest.net/licenses" target="_blank" rel="nofollow">Marketplace Licenses page</a><a href="http://themeforest.net/licenses" target="_blank" rel="nofollow">.</a>', 1, 1, '2014-10-03', 1),
(2, 'What is Copyright?', 'Copyright is a legal concept that gives the author or creator of an original work the exclusive right to do certain things with that original work. The copyright holder has the right to choose if anyone else can use, adapt or resell their work and has the right to be credited for that work.&nbsp;Copyright protection is principally given to works that are literary, dramatic, artistic and musical works, cinematograph film, and television and sound broadcasts.Only the copyright holder of a work may do the these things:<ol><li>Make copies of the work and distribute it.</li><li>Create derivative works or alter the work.</li><li>Sell the work in either its original version or in an altered form.</li></ol>The creator of a work retains copyright to it even if they do not expressly tell you so.', 1, 1, '2014-10-03', 2),
(3, 'Where can I find my Purchase Code?', 'After you’ve completed a purchase, the download links for the item are automatically added to your Marketplace account’s download area. The download links you receive will include a Main File or Installation package and also the License Certificate which includes your Purchase Code.To access your Purchase Code for an item:<ol><li>Log into your Marketplace account</li><li>From your account dropdown links, select ‘Downloads’</li><li>Click the ‘Download’ button that corresponds with your purchase</li><li>Select the ‘License certificate &amp; purchase code’ download link.&nbsp;Your Purchase Code will be displayed within the License Certificate.</li></ol>', 1, 1, '2014-10-03', 2),
(4, 'What are licenses and where can I learn about them?', 'When you ''purchase'' an item from one of our Marketplaces, you''re actually purchasing a license to use that item. Some items have several options for licenses, depending on what you plan to do with the item.&nbsp;All the information on our licenses, including an overview, FAQs, and complete licensing terms can be found on the&nbsp;<a href="http://themeforest.net/licenses" target="_blank" rel="nofollow">Marketplace Licenses page</a><a href="http://themeforest.net/licenses" target="_blank" rel="nofollow">.</a>', 1, 1, '2014-10-03', 1),
(5, 'Where can I find my Purchase Code?', 'After you’ve completed a purchase, the download links for the item are automatically added to your Marketplace account’s download area. The download links you receive will include a Main File or Installation package and also the License Certificate which includes your Purchase Code.To access your Purchase Code for an item:<ol><li>Log into your Marketplace account</li><li>From your account dropdown links, select ‘Downloads’</li><li>Click the ‘Download’ button that corresponds with your purchase</li><li>Select the ‘License certificate &amp; purchase code’ download link.&nbsp;Your Purchase Code will be displayed within the License Certificate.</li></ol>', 1, 1, '2014-10-03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `faq_grp`
--

CREATE TABLE `faq_grp` (
  `faq_grp_id` int(11) NOT NULL,
  `faq_grp_name` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq_grp`
--

INSERT INTO `faq_grp` (`faq_grp_id`, `faq_grp_name`) VALUES
(1, 'Common'),
(2, 'Learner'),
(3, 'Instructor');

-- --------------------------------------------------------

--
-- Table structure for table `feature_list`
--

CREATE TABLE `feature_list` (
  `feature_id` int(11) NOT NULL,
  `feature_item` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `feature_list`
--

INSERT INTO `feature_list` (`feature_id`, `feature_item`, `parent_id`) VALUES
(1, '15 Days validity.', 1),
(2, 'Unlimited paid exams.', 1),
(3, 'Unlimited certificate.', 1),
(4, '24h access.', 1),
(5, '6 Months validity.', 2),
(6, 'Unlimited&nbsp;paid&nbsp;exams.', 2),
(7, 'Unlimited certificate.&nbsp;', 2),
(8, 'Best value', 2),
(9, '12 Months validity', 3),
(10, 'Unlimited paid&nbsp;exams', 3),
(11, 'Unlimited&nbsp;certificate', 3),
(12, 'Design for professionals.', 3),
(13, '<b>5 Years</b> validity', 4),
(14, 'Unlimited paid&nbsp;exams.', 4),
(15, 'Unlimited&nbsp;certificates.', 4),
(16, 'Learn for long time.', 4);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(10) NOT NULL,
  `message_sender` varchar(100) CHARACTER SET utf8 DEFAULT '',
  `sender_email` varchar(100) CHARACTER SET utf8 DEFAULT '',
  `message_send_to` varchar(100) CHARACTER SET utf8 DEFAULT '',
  `message_subject` text CHARACTER SET utf8,
  `message_body` text CHARACTER SET utf8,
  `message_date` datetime DEFAULT NULL,
  `message_folder` varchar(10) CHARACTER SET utf8 DEFAULT '',
  `message_read` tinyint(4) DEFAULT '0' COMMENT '0=unread,1=read',
  `spam` tinyint(4) DEFAULT '0' COMMENT '0=No,1=Yes',
  `trash` tinyint(4) DEFAULT '0' COMMENT '0=No,1=Yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `message_sender`, `sender_email`, `message_send_to`, `message_subject`, `message_body`, `message_date`, `message_folder`, `message_read`, `spam`, `trash`) VALUES
(1, 'Student', 'student@demo.com', '0', 'uhuh', 'klkkk<br>', '2014-10-05 23:29:49', 'inbox', 1, 1, 0),
(5, 'Student', 'student@demo.com', '0', 'thx', 'thx<br><br>', '2014-10-08 13:04:49', 'inbox', 1, 0, 0),
(11, 'Student', 'student@demo.com', '0', 'Excellent', 'Nice', '2014-11-08 17:02:19', 'inbox', 1, 0, 0),
(12, 'Test', 'test@test.com', '0', 'Testing', 'My Test<br>', '2014-11-08 17:06:54', 'inbox', 1, 0, 0),
(14, 'Ugg Boots Sale', 'Ugg Boots Sale', '0', 'vfjhzxjtyna@gmail.com', 'Pro, sorry evaluation of late, traveling to play a few days before I came back to my sister to buy, my sister liked, well thank you parents to send a small gift, I wish the seller business is booming!\n <a href="http://expatdoctormom.com/uggmom/">Ugg Boots Sale</a>\n[url=http://expatdoctormom.com/uggmom/]Ugg Boots Sale[/url]', '2014-11-10 02:20:49', 'inbox', 1, 0, 0),
(19, 'okulyuv', 'abaces@rettmail.com', '0', 'Functionally perineum; domperidone cadaveric reabsorption dissect enquiry. ', 'http://viagra-genericbuy.com/ - Viagra Discount <a href="http://generic-viagradiscount.com/">Viagra</a> http://viagrapriceof.com/', '2014-11-28 01:59:08', 'inbox', 1, 0, 0),
(22, 'Jon', 'jon.galabroi@gmail.com', '0', 'Minor school', '<span>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\nCan I create subjective (essay type) exam items?</span>\n\nThese are open ended questions where\ncandidates will have to respond in writing. So, it means that the result will not\nbe shown to them directly but it will be sent to us initially.\n\n<span>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\nDoes it have any protection for cheating? For\nexample to prohibit copy-paste, screenshots, etc…</span>\n\n<span>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\nThese exams will have to be proctored. Do you\nhave an option where a proctor will login and initiate an exam session for a candidate?</span>\n\n<span>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\nAnd can a proctor send a report after?</span>\n\nThank you!\n\n<br><br><br><br>', '2014-12-03 08:52:05', 'inbox', 1, 0, 0),
(27, 'acheter cialis', 'georgesai@mail.ru', '0', 'Thanks for the good writeup. It in reality was a enjoyment account it.', 'I used to be able to find good advice from your content.| \nThank you for every other magnificent post. The place else could anyone get that kind of info in such an ideal means of writing? I''ve a presentation subsequent week, and I am on the look for', '2014-12-25 11:51:18', 'inbox', 1, 0, 0),
(37, 'Chad R', 'w@1stpageplan.com', '0', 'Quick question about your page', 'I went through http://minorschool.net this afternoon and just wondered if you''ve done any search engine marketing yet. I am self-employed doing that for various businesses for a number of years now, it''s been putting food on the table doing it, so I won''t complain.\n\nIf you''ve looked around in the past, most companies will agree it has everything to do with your number and quality of inbound links, site content and social media. So I wouldn''t say I have a secret no one else does in that manner.  What I do have that no one else has, is that I am working side by side with various networks that allows me to have your site open up whenever your competitors sites are visited.  You can imagine what you could do with this.\n\nThe only thing that makes me different is that I don''t have to charge large amounts of money as I don''t have employees or overhead. If you''d like to see some references please just ask, I''d be happy to send a few over.\n\nSome of the things I can help with is;\n\n1.  Optimize your site so that its exactly what Google wants to see based on what your top ten competitors have already done and are doing.  \n2.  Fix Penguin 3.0 issues to fix recent dropped listings and improve them.  \n3.  Make your site mobile & pad friendly.\n4.  Automate much of your social media tasks including posts, signing up for more, gaining more followers.  \n5.  Making sure your site is seen, even if a visitor goes to one of your competitors sites.  \n6.  Making sure past visitors are reminded to go back to your site should they ever need what it is you''re offering.  \n7.  Offer you a Heatmap technology solution better than CrazyEgg and ClickTale.  \n8.  Auto post relevant content to your blogs, and auto update your social media accounts with each post.  \n\nI start at only 99 a month so there''s no reason to at least request more information.\n\n\nChad\n331-223-9026', '2015-01-26 22:51:18', 'inbox', 1, 0, 0),
(38, 'Abdul Hannan Khan Munna', 'bd.munna@hotmail.com', '0', 'testing inbox', 'dlkfjdfjlfjlkfjlkfjlkf', '2016-03-19 14:30:27', 'inbox', 1, 0, 0),
(39, 'nfgngfn', 'admin1@demo.com', '0', 'trntnrngf', 'vcdfe', '2016-06-24 13:24:39', 'inbox', 1, 0, 0),
(40, 'Super Admin', 'support@demo.com', 'bd.munna@hotmail.com', 'dfdsfdsfds', 'fdsfdsf', '2017-03-17 16:53:30', 'send', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `messages_reply`
--

CREATE TABLE `messages_reply` (
  `message_reply_id` int(10) NOT NULL,
  `message_id_fk` int(10) DEFAULT NULL,
  `replied_messages` text CHARACTER SET utf8,
  `replied_by` int(5) DEFAULT NULL,
  `replied_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `messages_reply`
--

INSERT INTO `messages_reply` (`message_reply_id`, `message_id_fk`, `replied_messages`, `replied_by`, `replied_time`) VALUES
(1, 39, 'test reply', 1, '2017-03-09 22:03:15'),
(2, 39, 'jggjgjhkjhkhjk', 1, '2017-03-09 23:04:59'),
(3, 39, 'jggjgjhkjhkhjk', 1, '2017-03-09 23:05:59'),
(4, 39, 'jggjgjhkjhkhjk', 1, '2017-03-09 23:06:45');

-- --------------------------------------------------------

--
-- Table structure for table `noticeboard`
--

CREATE TABLE `noticeboard` (
  `notice_id` int(11) NOT NULL,
  `notice_title` text COLLATE utf8_unicode_ci,
  `notice_descr` text COLLATE utf8_unicode_ci,
  `notice_start` date DEFAULT NULL,
  `notice_end` date DEFAULT NULL,
  `notice_status` int(1) DEFAULT '1',
  `notice_created_by` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `noticeboard`
--

INSERT INTO `noticeboard` (`notice_id`, `notice_title`, `notice_descr`, `notice_start`, `notice_end`, `notice_status`, `notice_created_by`) VALUES
(1, 'Short Notice', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu urna sit amet libero posuere egestas. Aenean et enim eget dolor fringilla pulvinar. Pellentesque elit libero, placerat et eros id, pretium interdum nibh.', '2014-09-30', '2020-09-30', 1, 1),
(2, 'Notice Example', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu urna sit amet libero posuere egestas. Aenean et enim eget dolor fringilla pulvinar. Pellentesque elit libero, placerat et eros id, pretium interdum nibh.', '2014-09-30', '2020-06-30', 1, 1),
(3, 'Notice Title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu urna sit amet libero posuere egestas. Aenean et enim eget dolor fringilla pulvinar. Pellentesque elit libero, placerat et eros id, pretium interdum nibh.', '2014-09-30', '2020-12-31', 1, 1),
(4, 'Test notice', 'dsfsdfsdfsdfsdf', '2017-01-21', '2017-01-31', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_history`
--

CREATE TABLE `payment_history` (
  `pay_id` int(8) NOT NULL,
  `payer_id` varchar(100) NOT NULL,
  `pay_amount` varchar(20) NOT NULL,
  `currency_code` varchar(50) DEFAULT '',
  `token` varchar(100) DEFAULT '',
  `user_id_ref` int(5) DEFAULT NULL,
  `payment_reference` text,
  `pay_date` date DEFAULT NULL,
  `pay_method` varchar(25) DEFAULT '',
  `gateway_reference` varchar(256) DEFAULT '',
  `payment_type` varchar(22) DEFAULT 'exam'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_history`
--

INSERT INTO `payment_history` (`pay_id`, `payer_id`, `pay_amount`, `currency_code`, `token`, `user_id_ref`, `payment_reference`, `pay_date`, `pay_method`, `gateway_reference`, `payment_type`) VALUES
(1, 'NLEYX9HDPRSLL', '15', ' ', 'EC-201467350C254015V', 1, 'Basic Rules of Illustration', '2017-01-12', 'PayPal', '38W22958LW101673U', 'Course'),
(2, 'ahkmunna-buyer@ymail.com', '20.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2016-10-13', 'PayPal', '2BU48709WP5963530', 'Course'),
(3, 'ahkmunna-buyer@ymail.com', '10.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2017-03-13', 'PayPal', '2BU48709WP5963530', 'Course'),
(4, 'NLEYX9HDPRSLL', '15', ' ', 'EC-201467350C254015V', 1, 'Basic Rules of Illustration', '2017-01-12', 'PayPal', '38W22958LW101673U', 'Course'),
(5, 'ahkmunna-buyer@ymail.com', '10.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2017-02-13', 'PayPal', '2BU48709WP5963530', 'Course'),
(6, 'ahkmunna-buyer@ymail.com', '10.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2017-03-13', 'PayPal', '2BU48709WP5963530', 'Course'),
(7, 'ahkmunna-buyer@ymail.com', '10.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2017-02-13', 'PayPal', '2BU48709WP5963530', 'Course'),
(8, 'ahkmunna-buyer@ymail.com', '10.00', 'USD', 'AP-85191363VX067903S', 1, 'Payment for course:Basic Rules of Illustration', '2016-12-13', 'PayPal', '2BU48709WP5963530', 'Course');

-- --------------------------------------------------------

--
-- Table structure for table `paypal_settings`
--

CREATE TABLE `paypal_settings` (
  `id` int(5) NOT NULL,
  `enabled` int(1) DEFAULT '1' COMMENT '0 = ''Disabled'' ,1 = ''Enabled''',
  `commission_percent` int(11) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT '',
  `currency_id` int(3) NOT NULL,
  `application_id` text,
  `api_username` varchar(255) DEFAULT '',
  `api_pass` varchar(255) DEFAULT '',
  `api_signature` text,
  `sandbox` int(1) NOT NULL DEFAULT '1' COMMENT '1=Sandbox, 0=Live'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `paypal_settings`
--

INSERT INTO `paypal_settings` (`id`, `enabled`, `commission_percent`, `paypal_email`, `currency_id`, `application_id`, `api_username`, `api_pass`, `api_signature`, `sandbox`) VALUES
(1, 1, 100, 'agb_1296755685_biz@angelleye.com', 151, 'APP-80W284485P519543T', 'sdk-three_api1.sdk.com', 'QFZCWN5HZM8VBG7Q', 'A-IzJhZZjhg29XQ2qnhapuwxIDzyAZQ92FRP5dqBzVesOkzbdUONzmOU', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payu_settings`
--

CREATE TABLE `payu_settings` (
  `id` int(5) NOT NULL,
  `enabled` int(1) DEFAULT '1' COMMENT '0 = ''Disabled'' ,1 = ''Enabled''',
  `merchant_key` text,
  `salt` text,
  `sandbox` int(1) NOT NULL DEFAULT '1' COMMENT '1=Sandbox, 0=Live'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payu_settings`
--

INSERT INTO `payu_settings` (`id`, `enabled`, `merchant_key`, `salt`, `sandbox`) VALUES
(1, 0, 'JBZaLc', 'GQs7yium', 1);

-- --------------------------------------------------------

--
-- Table structure for table `price_table`
--

CREATE TABLE `price_table` (
  `price_table_id` int(11) NOT NULL,
  `price_table_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `price_table_cost` varchar(20) COLLATE utf8_unicode_ci DEFAULT '',
  `offer_duration` int(11) DEFAULT NULL,
  `offer_type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '',
  `price_table_top` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `price_table`
--

INSERT INTO `price_table` (`price_table_id`, `price_table_title`, `price_table_cost`, `offer_duration`, `offer_type`, `price_table_top`) VALUES
(1, 'Basic', '10', 15, 'days', 0),
(2, 'Premium', '99.99', 6, 'months', 0),
(3, 'Pro', '199', 1, 'years', 0),
(4, 'Pro +', '499', 5, 'years', 1);

-- --------------------------------------------------------

--
-- Table structure for table `puchase_history`
--

CREATE TABLE `puchase_history` (
  `purchase_id` int(11) NOT NULL,
  `type` varchar(20) DEFAULT 'course',
  `user_id` int(11) DEFAULT NULL,
  `pur_ref_id` int(11) DEFAULT NULL,
  `pur_date` date DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `puchase_history`
--

INSERT INTO `puchase_history` (`purchase_id`, `type`, `user_id`, `pur_ref_id`, `pur_date`, `payment_id`) VALUES
(1, 'Course', 1, 3, '2017-03-12', 1),
(2, 'Course', 1, 3, '2017-03-13', 2);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `ques_id` int(5) NOT NULL,
  `question` text COLLATE utf8_unicode_ci,
  `exam_id` int(5) DEFAULT NULL,
  `option_type` text CHARACTER SET utf8,
  `media_type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '',
  `media_link` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`ques_id`, `question`, `exam_id`, `option_type`, `media_type`, `media_link`) VALUES
(8, 'Name of the renowned shirt maker in Jermyn Street, London?', 2, 'Radio', '', ''),
(9, 'The equal combination of green and blue light, and the C in CMYK color printing, are what?', 2, 'Radio', '', ''),
(10, 'What is a tone of photography which results from or gives the effect of age?', 2, 'Radio', '', ''),
(11, 'What colour is Tyrian, a dye highly prized by the Romans?', 2, 'Radio', '', ''),
(12, 'What colour derives from the Latin root word meaning shade?', 2, 'Radio', '', ''),
(14, 'When I first meet someone,', 3, 'Radio', '', ''),
(15, 'When I am listening to the other person,', 3, 'Radio', '', ''),
(16, 'When I’m in a group,', 3, 'Radio', '', ''),
(17, 'When I receive unfavorable feedback,', 3, 'Radio', '', ''),
(18, 'When I disagree with the feedback I received,', 3, 'Radio', '', ''),
(19, 'While conversing,', 3, 'Radio', '', ''),
(20, 'While conversing,', 3, 'Radio', '', ''),
(21, 'While conversing,', 3, 'Radio', '', ''),
(22, 'When I have a negative opinion or comment,<br>', 3, 'Radio', '', ''),
(23, 'When someone talks about an unfortunate or sad experience,', 3, 'Radio', '', ''),
(25, 'Which city in Russia hosted the XXII Olympic Winter Games?', 5, 'Radio', '', ''),
(26, '<pre>Which one of the following is not the function of Personnel Management?</pre>', 5, 'Radio', '', ''),
(27, '<pre>Which of the following is generally an inappropriate reason for delegation?</pre>', 5, 'Radio', '', ''),
(28, '<pre>Which of the following is a current liability of a business?</pre>', 5, 'Radio', '', ''),
(29, '<pre>Which of the following is not a financial statement?</pre>', 5, 'Radio', '', ''),
(30, '<pre>A tool to plot the duration of activities in a project and its dependencies is named after:</pre>', 5, 'Radio', '', ''),
(31, '<pre>Which item appears in both the balance sheet and the profit and loss account?</pre>', 5, 'Radio', '', ''),
(32, '<pre>A tool for evaluating organizational performance across the full range of a business is known as a ''balanced ________''.</pre>', 5, 'Radio', '', ''),
(33, '<pre>What is the main advantage of employing staff on a temporary basis?</pre>', 5, 'Radio', '', ''),
(34, '<pre>Which of the following can be used as a term for Supervisor?</pre>', 5, 'Radio', '', ''),
(35, '<pre>Which ratio shows an organization''s effectiveness in minimizing production costs?</pre>', 5, 'Radio', '', ''),
(36, 'In order to to display a widget, the user must _____', 0, 'Radio', 'audio', 'audio/568c0831e877f.mp3'),
(37, '&nbsp;Image size can be set __________', 0, 'Radio', '', ''),
(38, 'Which of the following blog site can be imported into wordpress?', 0, 'Radio', '', ''),
(39, 'A webpage displays a picture. What tag was used to display that picture?', 6, 'Checkbox', '', ''),
(40, '&lt;b&gt; tag makes the enclosed text bold. What is other tag to make text bold?', 0, 'Checkbox', 'video', 'video/568ce7021ff8c.mp4'),
(41, 'Tags and test that are not directly displayed on the page are written in _____ section.', 0, 'Checkbox', 'audio', 'audio/568ce842e7a00.mp3'),
(42, 'Which tag inserts a line horizontally on your web page?', 0, 'Checkbox', '', ''),
(43, 'What should be the first tag in any HTML document?', 0, 'Checkbox', '', ''),
(44, 'Which tag allows you to add a row in a table?', 0, 'Checkbox', '', ''),
(45, 'How can you make a bulleted list?', 0, 'Checkbox', '', ''),
(47, 'A webpage displays a picture. What tag was used to display that picture?', 6, 'Checkbox', '', ''),
(48, '&lt;b&gt; tag makes the enclosed text bold. What is other tag to make text bold?', 6, 'Checkbox', '', ''),
(49, 'Tags and test that are not directly displayed on the page are written in _____ section.', 0, 'Checkbox', '', ''),
(50, 'Which tag inserts a line horizontally on your web page?', 0, 'Checkbox', '', ''),
(51, 'What does vlink attribute mean?', 6, 'Radio', '', ''),
(52, 'Which attribute is used to name an element uniquely?', 6, 'Checkbox', '', ''),
(53, 'The special formatting codes in HTML document used to present content are<br>a. tags', 6, 'Radio', '', ''),
(54, 'Some tags enclose the text. Those tags are known as', 6, 'Radio', '', ''),
(60, 'Name the diagram', 2, 'Radio', 'image', 'image/58542bdd8517f.png'),
(61, 'Simple audio test', 2, 'Radio', 'audio', 'audio/58542c4f2af8d.mp3'),
(62, 'Youtube test', 2, 'Radio', 'youtube', 'https://www.youtube.com/watch?v=w_Yp5_QP46U'),
(63, 'Video sample', 2, 'Radio', 'video', 'video/58542d10410c9.mp4'),
(66, 'test audio', 2, 'Radio', 'audio', 'audio/5883c585b0aed.mp3'),
(67, 'test vdo', 2, 'Radio', 'video', 'video/5883c5ba2b4ec.mp4'),
(68, 'Test audio', 10, 'Radio', 'audio', 'audio/5883c864786ee.mp3'),
(69, 'QQQ', 11, 'Radio', 'image', 'image/58cc3581a8ff3.png'),
(70, 'qqqq2', 11, 'Radio', 'audio', 'audio/58cc438fd0622.mp3'),
(71, 'img test', 2, 'Checkbox', 'image', 'image/58ce9dd9b8436.png');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `result_id` int(5) NOT NULL,
  `exam_id` int(5) DEFAULT NULL,
  `user_id` int(5) DEFAULT NULL,
  `result_percent` varchar(6) CHARACTER SET utf8 DEFAULT '' COMMENT '(%)',
  `question_answered` int(3) DEFAULT NULL,
  `exam_taken_date` datetime DEFAULT NULL,
  `result_json` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`result_id`, `exam_id`, `user_id`, `result_percent`, `question_answered`, `exam_taken_date`, `result_json`) VALUES
(1, 1, 1, '0', 6, '2016-09-25 21:58:54', '{"2":"7","6":"23","3":"11","46":"180","1":"2","5":"18"}'),
(2, 1, 1, '0', 0, '2016-12-14 00:42:06', '{"55":"210"}'),
(3, 1, 1, '0', 0, '2016-12-14 00:48:06', '{"2":"6"}'),
(4, 1, 1, '0', 4, '2016-12-14 01:05:51', '{"46":"180","2":"6","3":"11","1":"3"}'),
(5, 1, 1, '25', 4, '2016-12-14 01:10:31', '{"56":"213","55":"210"}'),
(6, 3, 1, '40', 10, '2016-12-16 03:17:40', '{"20":"78","18":"70","19":"74","22":"86","21":"81","16":"61","14":"54","15":"57","17":"66","23":"91"}'),
(7, 2, 5, '25', 8, '2016-12-18 12:57:52', '{"12":"46","60":"224","8":"31","63":"233","11":"42","61":"228","9":"34","62":"230"}'),
(8, 2, 5, '37.5', 8, '2016-12-20 14:25:13', '{"10":"38","12":"46","62":"229","8":"30","60":"224","63":"231","11":"41","61":"228"}'),
(9, 3, 5, '10', 10, '2016-12-20 14:26:23', '{"23":"92","20":"78"}'),
(10, 3, 5, '60', 10, '2016-12-20 14:27:02', '{"21":"81","16":"62","15":"58","20":"79","23":"91","17":"65","18":"71","22":"86","19":"73","14":"53"}'),
(11, 2, 5, '37.5', 8, '2016-12-28 16:20:16', '{"10":"37","8":"30","60":"225","61":"226","63":"231","62":"229","9":"34"}'),
(12, 2, 1, '0', 8, '2016-12-29 17:59:57', '{"10":"39"}'),
(13, 2, 1, '25', 8, '2016-12-29 18:20:13', '{"61":"226","10":"39","8":"29"}'),
(14, 2, 5, '37.5', 8, '2016-12-30 07:26:32', '{"61":"226","60":"225","9":"35","10":"37","12":"47","63":"231","62":"229","11":"43"}'),
(15, 3, 5, '80', 10, '2016-12-30 21:13:02', '{"22":"86","23":"91","21":"81","18":"71","16":"62","15":"59","19":"76","20":"78","14":"54","17":"65"}'),
(16, 2, 5, '50', 8, '2016-12-30 22:05:52', '{"11":"42","61":"226","9":"35","62":"229","10":"38","8":"31","63":"233","60":"224"}'),
(17, 3, 5, '30', 10, '2017-01-01 23:27:31', '{"19":"75","15":"58","20":"79","17":"65","16":"62","22":"87","18":"71","21":"81","14":"53","23":"90"}');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `brand_id` int(1) NOT NULL,
  `brand_name` varchar(50) DEFAULT '',
  `brand_tagline` varchar(250) DEFAULT '',
  `local_time_zone` varchar(100) DEFAULT '',
  `support_email` varchar(100) DEFAULT '',
  `support_phone` varchar(50) DEFAULT '',
  `address` text,
  `facbook_url` text,
  `googleplus_url` text,
  `linkedin_url` text,
  `you_tube_url` text,
  `flickr_url` text,
  `twitter_url` text,
  `pinterest_url` text,
  `show_video_on_home` int(1) DEFAULT '0',
  `student_can_register` int(1) DEFAULT '1',
  `teacher_can_register` int(1) DEFAULT '1',
  `teacher_can_create_categories` int(1) DEFAULT '1',
  `teacher_can_create_blogs` int(1) DEFAULT '1',
  `last_update` date DEFAULT NULL,
  `commercial` int(11) DEFAULT '1',
  `show_latest_courses_on_homepage` int(1) DEFAULT '1',
  `show_latest_exams_on_homepage` int(1) DEFAULT '0',
  `number_of_latest_course` int(1) DEFAULT '4',
  `number_of_latest_exam` int(1) DEFAULT '4'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`brand_id`, `brand_name`, `brand_tagline`, `local_time_zone`, `support_email`, `support_phone`, `address`, `facbook_url`, `googleplus_url`, `linkedin_url`, `you_tube_url`, `flickr_url`, `twitter_url`, `pinterest_url`, `show_video_on_home`, `student_can_register`, `teacher_can_register`, `teacher_can_create_categories`, `teacher_can_create_blogs`, `last_update`, `commercial`, `show_latest_courses_on_homepage`, `show_latest_exams_on_homepage`, `number_of_latest_course`, `number_of_latest_exam`) VALUES
(1, 'Minor School', 'Learning freedom for all.', 'Asia/Dhaka', 'support@demo.com', '09999999', '121 King Street, Melbourne  Victoria 3000 Australia', 'https://www.facebook.com/ahkmunna', '', 'https://twitter.com/ahkmunna', 'https://www.youtube.com/watch?v=dlJshzOv2cw', '', 'https://twitter.com/ahkmunna', 'https://twitter.com/ahkmunna', 1, 1, 0, 1, 0, '2017-03-24', 1, 1, 0, 8, 4);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(10) NOT NULL,
  `sub_cat_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `cat_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `sub_cat_active` int(1) DEFAULT '1',
  `last_modified_by` int(5) DEFAULT NULL,
  `icon_class` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `sub_cat_name`, `cat_id`, `created_by`, `sub_cat_active`, `last_modified_by`, `icon_class`) VALUES
(1, 'Typography', 3, 1, 1, 1, NULL),
(2, 'Sketch', 3, 1, 1, 1, NULL),
(3, 'Illustration', 3, 1, 1, 1, NULL),
(4, 'Color', 3, 1, 1, 1, NULL),
(5, 'Communication', 5, 1, 1, 1, NULL),
(6, 'Leadership', 5, 1, 1, 1, NULL),
(7, 'Productivity', 5, 1, 1, 1, NULL),
(8, 'Management Skills', 5, 1, 0, 1, NULL),
(9, 'Web Development', 1, 1, 0, 1, NULL),
(10, 'Programming Language', 1, 1, 1, 1, NULL),
(11, 'Desktop Apps', 1, 1, 1, 1, NULL),
(12, 'Mobile Apps', 1, 1, 1, 1, NULL),
(13, 'E-learning', 4, 1, 1, 1, NULL),
(14, 'Teacher Tools', 4, 1, 1, 1, NULL),
(15, 'Web Design', 2, 1, 1, 1, NULL),
(16, 'Web Graphics', 2, 1, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `timezone`
--

CREATE TABLE `timezone` (
  `timezone_id` smallint(5) UNSIGNED NOT NULL,
  `timezone_name` varchar(255) NOT NULL,
  `country_id` smallint(5) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `timezone`
--

INSERT INTO `timezone` (`timezone_id`, `timezone_name`, `country_id`) VALUES
(1, 'Europe/Andorra', 1),
(2, 'Asia/Dubai', 2),
(3, 'Asia/Kabul', 3),
(4, 'America/Antigua', 4),
(5, 'America/Anguilla', 5),
(6, 'Europe/Tirane', 6),
(7, 'Asia/Yerevan', 7),
(8, 'Africa/Luanda', 8),
(9, 'Antarctica/Casey', 9),
(10, 'Antarctica/Davis', 9),
(11, 'Antarctica/DumontDUrville', 9),
(12, 'Antarctica/Mawson', 9),
(13, 'Antarctica/McMurdo', 9),
(14, 'Antarctica/Palmer', 9),
(15, 'Antarctica/Rothera', 9),
(16, 'Antarctica/South_Pole', 9),
(17, 'Antarctica/Syowa', 9),
(18, 'Antarctica/Vostok', 9),
(19, 'America/Argentina/Buenos_Aires', 10),
(20, 'America/Argentina/Catamarca', 10),
(21, 'America/Argentina/Cordoba', 10),
(22, 'America/Argentina/Jujuy', 10),
(23, 'America/Argentina/La_Rioja', 10),
(24, 'America/Argentina/Mendoza', 10),
(25, 'America/Argentina/Rio_Gallegos', 10),
(26, 'America/Argentina/Salta', 10),
(27, 'America/Argentina/San_Juan', 10),
(28, 'America/Argentina/San_Luis', 10),
(29, 'America/Argentina/Tucuman', 10),
(30, 'America/Argentina/Ushuaia', 10),
(31, 'Pacific/Pago_Pago', 11),
(32, 'Europe/Vienna', 12),
(33, 'Antarctica/Macquarie', 13),
(34, 'Australia/Adelaide', 13),
(35, 'Australia/Brisbane', 13),
(36, 'Australia/Broken_Hill', 13),
(37, 'Australia/Currie', 13),
(38, 'Australia/Darwin', 13),
(39, 'Australia/Eucla', 13),
(40, 'Australia/Hobart', 13),
(41, 'Australia/Lindeman', 13),
(42, 'Australia/Lord_Howe', 13),
(43, 'Australia/Melbourne', 13),
(44, 'Australia/Perth', 13),
(45, 'Australia/Sydney', 13),
(46, 'America/Aruba', 14),
(47, 'Europe/Mariehamn', 15),
(48, 'Asia/Baku', 16),
(49, 'Europe/Sarajevo', 17),
(50, 'America/Barbados', 18),
(51, 'Asia/Dhaka', 19),
(52, 'Europe/Brussels', 20),
(53, 'Africa/Ouagadougou', 21),
(54, 'Europe/Sofia', 22),
(55, 'Asia/Bahrain', 23),
(56, 'Africa/Bujumbura', 24),
(57, 'Africa/Porto-Novo', 25),
(58, 'America/St_Barthelemy', 26),
(59, 'Atlantic/Bermuda', 27),
(60, 'Asia/Brunei', 28),
(61, 'America/La_Paz', 29),
(62, 'America/Kralendijk', 30),
(63, 'America/Araguaina', 31),
(64, 'America/Bahia', 31),
(65, 'America/Belem', 31),
(66, 'America/Boa_Vista', 31),
(67, 'America/Campo_Grande', 31),
(68, 'America/Cuiaba', 31),
(69, 'America/Eirunepe', 31),
(70, 'America/Fortaleza', 31),
(71, 'America/Maceio', 31),
(72, 'America/Manaus', 31),
(73, 'America/Noronha', 31),
(74, 'America/Porto_Velho', 31),
(75, 'America/Recife', 31),
(76, 'America/Rio_Branco', 31),
(77, 'America/Santarem', 31),
(78, 'America/Sao_Paulo', 31),
(79, 'America/Nassau', 32),
(80, 'Asia/Thimphu', 33),
(81, 'Africa/Gaborone', 35),
(82, 'Europe/Minsk', 36),
(83, 'America/Belize', 37),
(84, 'America/Atikokan', 38),
(85, 'America/Blanc-Sablon', 38),
(86, 'America/Cambridge_Bay', 38),
(87, 'America/Creston', 38),
(88, 'America/Dawson', 38),
(89, 'America/Dawson_Creek', 38),
(90, 'America/Edmonton', 38),
(91, 'America/Glace_Bay', 38),
(92, 'America/Goose_Bay', 38),
(93, 'America/Halifax', 38),
(94, 'America/Inuvik', 38),
(95, 'America/Iqaluit', 38),
(96, 'America/Moncton', 38),
(97, 'America/Montreal', 38),
(98, 'America/Nipigon', 38),
(99, 'America/Pangnirtung', 38),
(100, 'America/Rainy_River', 38),
(101, 'America/Rankin_Inlet', 38),
(102, 'America/Regina', 38),
(103, 'America/Resolute', 38),
(104, 'America/St_Johns', 38),
(105, 'America/Swift_Current', 38),
(106, 'America/Thunder_Bay', 38),
(107, 'America/Toronto', 38),
(108, 'America/Vancouver', 38),
(109, 'America/Whitehorse', 38),
(110, 'America/Winnipeg', 38),
(111, 'America/Yellowknife', 38),
(112, 'Indian/Cocos', 39),
(113, 'Africa/Kinshasa', 40),
(114, 'Africa/Lubumbashi', 40),
(115, 'Africa/Bangui', 41),
(116, 'Africa/Brazzaville', 42),
(117, 'Europe/Zurich', 43),
(118, 'Africa/Abidjan', 44),
(119, 'Pacific/Rarotonga', 45),
(120, 'America/Santiago', 46),
(121, 'Pacific/Easter', 46),
(122, 'Africa/Douala', 47),
(123, 'Asia/Chongqing', 48),
(124, 'Asia/Harbin', 48),
(125, 'Asia/Kashgar', 48),
(126, 'Asia/Shanghai', 48),
(127, 'Asia/Urumqi', 48),
(128, 'America/Bogota', 49),
(129, 'America/Costa_Rica', 50),
(130, 'America/Havana', 51),
(131, 'Atlantic/Cape_Verde', 52),
(132, 'America/Curacao', 53),
(133, 'Indian/Christmas', 54),
(134, 'Asia/Nicosia', 55),
(135, 'Europe/Prague', 56),
(136, 'Europe/Berlin', 57),
(137, 'Europe/Busingen', 57),
(138, 'Africa/Djibouti', 58),
(139, 'Europe/Copenhagen', 59),
(140, 'America/Dominica', 60),
(141, 'America/Santo_Domingo', 61),
(142, 'Africa/Algiers', 62),
(143, 'America/Guayaquil', 63),
(144, 'Pacific/Galapagos', 63),
(145, 'Europe/Tallinn', 64),
(146, 'Africa/Cairo', 65),
(147, 'Africa/El_Aaiun', 66),
(148, 'Africa/Asmara', 67),
(149, 'Africa/Ceuta', 68),
(150, 'Atlantic/Canary', 68),
(151, 'Europe/Madrid', 68),
(152, 'Africa/Addis_Ababa', 69),
(153, 'Europe/Helsinki', 71),
(154, 'Pacific/Fiji', 72),
(155, 'Atlantic/Stanley', 73),
(156, 'Pacific/Chuuk', 74),
(157, 'Pacific/Kosrae', 74),
(158, 'Pacific/Pohnpei', 74),
(159, 'Atlantic/Faroe', 75),
(160, 'Europe/Paris', 76),
(161, 'Africa/Libreville', 77),
(162, 'Europe/London', 78),
(163, 'America/Grenada', 79),
(164, 'Asia/Tbilisi', 80),
(165, 'America/Cayenne', 81),
(166, 'Europe/Guernsey', 82),
(167, 'Africa/Accra', 83),
(168, 'Europe/Gibraltar', 84),
(169, 'America/Danmarkshavn', 85),
(170, 'America/Godthab', 85),
(171, 'America/Scoresbysund', 85),
(172, 'America/Thule', 85),
(173, 'Africa/Banjul', 86),
(174, 'Africa/Conakry', 87),
(175, 'America/Guadeloupe', 88),
(176, 'Africa/Malabo', 89),
(177, 'Europe/Athens', 90),
(178, 'Atlantic/South_Georgia', 91),
(179, 'America/Guatemala', 92),
(180, 'Pacific/Guam', 93),
(181, 'Africa/Bissau', 94),
(182, 'America/Guyana', 95),
(183, 'Asia/Hong_Kong', 96),
(184, 'America/Tegucigalpa', 98),
(185, 'Europe/Zagreb', 99),
(186, 'America/Port-au-Prince', 100),
(187, 'Europe/Budapest', 101),
(188, 'Asia/Jakarta', 102),
(189, 'Asia/Jayapura', 102),
(190, 'Asia/Makassar', 102),
(191, 'Asia/Pontianak', 102),
(192, 'Europe/Dublin', 103),
(193, 'Asia/Jerusalem', 104),
(194, 'Europe/Isle_of_Man', 105),
(195, 'Asia/Kolkata', 106),
(196, 'Indian/Chagos', 107),
(197, 'Asia/Baghdad', 108),
(198, 'Asia/Tehran', 109),
(199, 'Atlantic/Reykjavik', 110),
(200, 'Europe/Rome', 111),
(201, 'Europe/Jersey', 112),
(202, 'America/Jamaica', 113),
(203, 'Asia/Amman', 114),
(204, 'Asia/Tokyo', 115),
(205, 'Africa/Nairobi', 116),
(206, 'Asia/Bishkek', 117),
(207, 'Asia/Phnom_Penh', 118),
(208, 'Pacific/Enderbury', 119),
(209, 'Pacific/Kiritimati', 119),
(210, 'Pacific/Tarawa', 119),
(211, 'Indian/Comoro', 120),
(212, 'America/St_Kitts', 121),
(213, 'Asia/Pyongyang', 122),
(214, 'Asia/Seoul', 123),
(215, 'Asia/Kuwait', 124),
(216, 'America/Cayman', 125),
(217, 'Asia/Almaty', 126),
(218, 'Asia/Aqtau', 126),
(219, 'Asia/Aqtobe', 126),
(220, 'Asia/Oral', 126),
(221, 'Asia/Qyzylorda', 126),
(222, 'Asia/Vientiane', 127),
(223, 'Asia/Beirut', 128),
(224, 'America/St_Lucia', 129),
(225, 'Europe/Vaduz', 130),
(226, 'Asia/Colombo', 131),
(227, 'Africa/Monrovia', 132),
(228, 'Africa/Maseru', 133),
(229, 'Europe/Vilnius', 134),
(230, 'Europe/Luxembourg', 135),
(231, 'Europe/Riga', 136),
(232, 'Africa/Tripoli', 137),
(233, 'Africa/Casablanca', 138),
(234, 'Europe/Monaco', 139),
(235, 'Europe/Chisinau', 140),
(236, 'Europe/Podgorica', 141),
(237, 'America/Marigot', 142),
(238, 'Indian/Antananarivo', 143),
(239, 'Pacific/Kwajalein', 144),
(240, 'Pacific/Majuro', 144),
(241, 'Europe/Skopje', 145),
(242, 'Africa/Bamako', 146),
(243, 'Asia/Rangoon', 147),
(244, 'Asia/Choibalsan', 148),
(245, 'Asia/Hovd', 148),
(246, 'Asia/Ulaanbaatar', 148),
(247, 'Asia/Macau', 149),
(248, 'Pacific/Saipan', 150),
(249, 'America/Martinique', 151),
(250, 'Africa/Nouakchott', 152),
(251, 'America/Montserrat', 153),
(252, 'Europe/Malta', 154),
(253, 'Indian/Mauritius', 155),
(254, 'Indian/Maldives', 156),
(255, 'Africa/Blantyre', 157),
(256, 'America/Bahia_Banderas', 158),
(257, 'America/Cancun', 158),
(258, 'America/Chihuahua', 158),
(259, 'America/Hermosillo', 158),
(260, 'America/Matamoros', 158),
(261, 'America/Mazatlan', 158),
(262, 'America/Merida', 158),
(263, 'America/Mexico_City', 158),
(264, 'America/Monterrey', 158),
(265, 'America/Ojinaga', 158),
(266, 'America/Santa_Isabel', 158),
(267, 'America/Tijuana', 158),
(268, 'Asia/Kuala_Lumpur', 159),
(269, 'Asia/Kuching', 159),
(270, 'Africa/Maputo', 160),
(271, 'Africa/Windhoek', 161),
(272, 'Pacific/Noumea', 162),
(273, 'Africa/Niamey', 163),
(274, 'Pacific/Norfolk', 164),
(275, 'Africa/Lagos', 165),
(276, 'America/Managua', 166),
(277, 'Europe/Amsterdam', 167),
(278, 'Europe/Oslo', 168),
(279, 'Asia/Kathmandu', 169),
(280, 'Pacific/Nauru', 170),
(281, 'Pacific/Niue', 171),
(282, 'Pacific/Auckland', 172),
(283, 'Pacific/Chatham', 172),
(284, 'Asia/Muscat', 173),
(285, 'America/Panama', 174),
(286, 'America/Lima', 175),
(287, 'Pacific/Gambier', 176),
(288, 'Pacific/Marquesas', 176),
(289, 'Pacific/Tahiti', 176),
(290, 'Pacific/Port_Moresby', 177),
(291, 'Asia/Manila', 178),
(292, 'Asia/Karachi', 179),
(293, 'Europe/Warsaw', 180),
(294, 'America/Miquelon', 181),
(295, 'Pacific/Pitcairn', 182),
(296, 'America/Puerto_Rico', 183),
(297, 'Asia/Gaza', 184),
(298, 'Asia/Hebron', 184),
(299, 'Atlantic/Azores', 185),
(300, 'Atlantic/Madeira', 185),
(301, 'Europe/Lisbon', 185),
(302, 'Pacific/Palau', 186),
(303, 'America/Asuncion', 187),
(304, 'Asia/Qatar', 188),
(305, 'Indian/Reunion', 189),
(306, 'Europe/Bucharest', 190),
(307, 'Europe/Belgrade', 191),
(308, 'Asia/Anadyr', 192),
(309, 'Asia/Irkutsk', 192),
(310, 'Asia/Kamchatka', 192),
(311, 'Asia/Khandyga', 192),
(312, 'Asia/Krasnoyarsk', 192),
(313, 'Asia/Magadan', 192),
(314, 'Asia/Novokuznetsk', 192),
(315, 'Asia/Novosibirsk', 192),
(316, 'Asia/Omsk', 192),
(317, 'Asia/Sakhalin', 192),
(318, 'Asia/Ust-Nera', 192),
(319, 'Asia/Vladivostok', 192),
(320, 'Asia/Yakutsk', 192),
(321, 'Asia/Yekaterinburg', 192),
(322, 'Europe/Kaliningrad', 192),
(323, 'Europe/Moscow', 192),
(324, 'Europe/Samara', 192),
(325, 'Europe/Volgograd', 192),
(326, 'Africa/Kigali', 193),
(327, 'Asia/Riyadh', 194),
(328, 'Pacific/Guadalcanal', 195),
(329, 'Indian/Mahe', 196),
(330, 'Africa/Khartoum', 197),
(331, 'Europe/Stockholm', 198),
(332, 'Asia/Singapore', 199),
(333, 'Atlantic/St_Helena', 200),
(334, 'Europe/Ljubljana', 201),
(335, 'Arctic/Longyearbyen', 202),
(336, 'Europe/Bratislava', 203),
(337, 'Africa/Freetown', 204),
(338, 'Europe/San_Marino', 205),
(339, 'Africa/Dakar', 206),
(340, 'Africa/Mogadishu', 207),
(341, 'America/Paramaribo', 208),
(342, 'Africa/Juba', 209),
(343, 'Africa/Sao_Tome', 210),
(344, 'America/El_Salvador', 211),
(345, 'America/Lower_Princes', 212),
(346, 'Asia/Damascus', 213),
(347, 'Africa/Mbabane', 214),
(348, 'America/Grand_Turk', 215),
(349, 'Africa/Ndjamena', 216),
(350, 'Indian/Kerguelen', 217),
(351, 'Africa/Lome', 218),
(352, 'Asia/Bangkok', 219),
(353, 'Asia/Dushanbe', 220),
(354, 'Pacific/Fakaofo', 221),
(355, 'Asia/Dili', 222),
(356, 'Asia/Ashgabat', 223),
(357, 'Africa/Tunis', 224),
(358, 'Pacific/Tongatapu', 225),
(359, 'Europe/Istanbul', 226),
(360, 'America/Port_of_Spain', 227),
(361, 'Pacific/Funafuti', 228),
(362, 'Asia/Taipei', 229),
(363, 'Africa/Dar_es_Salaam', 230),
(364, 'Europe/Kiev', 231),
(365, 'Europe/Simferopol', 231),
(366, 'Europe/Uzhgorod', 231),
(367, 'Europe/Zaporozhye', 231),
(368, 'Africa/Kampala', 232),
(369, 'Pacific/Johnston', 233),
(370, 'Pacific/Midway', 233),
(371, 'Pacific/Wake', 233),
(372, 'America/Adak', 234),
(373, 'America/Anchorage', 234),
(374, 'America/Boise', 234),
(375, 'America/Chicago', 234),
(376, 'America/Denver', 234),
(377, 'America/Detroit', 234),
(378, 'America/Indiana/Indianapolis', 234),
(379, 'America/Indiana/Knox', 234),
(380, 'America/Indiana/Marengo', 234),
(381, 'America/Indiana/Petersburg', 234),
(382, 'America/Indiana/Tell_City', 234),
(383, 'America/Indiana/Vevay', 234),
(384, 'America/Indiana/Vincennes', 234),
(385, 'America/Indiana/Winamac', 234),
(386, 'America/Juneau', 234),
(387, 'America/Kentucky/Louisville', 234),
(388, 'America/Kentucky/Monticello', 234),
(389, 'America/Los_Angeles', 234),
(390, 'America/Menominee', 234),
(391, 'America/Metlakatla', 234),
(392, 'America/New_York', 234),
(393, 'America/Nome', 234),
(394, 'America/North_Dakota/Beulah', 234),
(395, 'America/North_Dakota/Center', 234),
(396, 'America/North_Dakota/New_Salem', 234),
(397, 'America/Phoenix', 234),
(398, 'America/Shiprock', 234),
(399, 'America/Sitka', 234),
(400, 'America/Yakutat', 234),
(401, 'Pacific/Honolulu', 234),
(402, 'America/Montevideo', 235),
(403, 'Asia/Samarkand', 236),
(404, 'Asia/Tashkent', 236),
(405, 'Europe/Vatican', 237),
(406, 'America/St_Vincent', 238),
(407, 'America/Caracas', 239),
(408, 'America/Tortola', 240),
(409, 'America/St_Thomas', 241),
(410, 'Asia/Ho_Chi_Minh', 242),
(411, 'Pacific/Efate', 243),
(412, 'Pacific/Wallis', 244),
(413, 'Pacific/Apia', 245),
(414, 'Asia/Aden', 246),
(415, 'Indian/Mayotte', 247),
(416, 'Africa/Johannesburg', 248),
(417, 'Africa/Lusaka', 249),
(418, 'Africa/Harare', 250),
(419, 'Australia/Canberra', 13),
(420, 'Australia/NSW', 13),
(421, 'Australia/North', 13),
(422, 'Australia/Queensland', 13),
(423, 'Australia/South', 13),
(424, 'Australia/Tasmania', 13),
(425, 'Australia/Victoria', 13),
(426, 'Australia/West', 13),
(427, 'Chile/Continental', 46),
(428, 'America/Indianapolis', 234);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL,
  `user_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT '',
  `user_email` varchar(150) CHARACTER SET utf8 DEFAULT '',
  `user_phone` varchar(100) CHARACTER SET utf8 DEFAULT '',
  `user_role_id` int(5) DEFAULT NULL,
  `user_pass` varchar(32) CHARACTER SET utf8 DEFAULT '',
  `paypal_id` varchar(150) CHARACTER SET utf8 DEFAULT NULL,
  `active` int(1) DEFAULT '0' COMMENT '1 = active, 0 = inactive',
  `banned` int(1) DEFAULT '0' COMMENT '1 = banned, 0 = active',
  `user_from` datetime DEFAULT NULL,
  `subscription_id` int(5) DEFAULT '0',
  `subscription_start` text COLLATE utf8_unicode_ci,
  `subscription_end` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_phone`, `user_role_id`, `user_pass`, `paypal_id`, `active`, `banned`, `user_from`, `subscription_id`, `subscription_start`, `subscription_end`) VALUES
(1, 'Super Admin', 'superadmin@demo.com', '435345345', 1, 'e10adc3949ba59abbe56e057f20f883e', 'frff@demo.com', 1, 0, '2016-01-04 00:00:00', 1, '', ''),
(2, 'Admin One', 'admin@demo.com', '', 2, 'e10adc3949ba59abbe56e057f20f883e', '', 1, 0, '2016-01-04 20:17:37', 3, '', ''),
(3, 'Moderator', 'moderator@demo.com', '', 4, 'e10adc3949ba59abbe56e057f20f883e', '', 1, 0, '2016-01-04 20:18:20', 1, '', '2021-03-20'),
(4, 'Teacher', 'teacher@demo.com', '', 4, 'e10adc3949ba59abbe56e057f20f883e', '', 1, 0, '2016-01-04 20:18:56', 3, '', '2021-03-20'),
(5, 'Student', 'student@demo.com', '', 5, 'e10adc3949ba59abbe56e057f20f883e', '', 1, 0, '2016-01-04 20:19:33', 1, '', '2021-02-20'),
(8, 'test user modified', 'admin1@demo.com', '', 3, 'e10adc3949ba59abbe56e057f20f883e', '', 1, 0, '2016-12-15 17:38:04', 2, '', '2021-03-20'),
(9, 'Munna Khan', 'bd.munna@hotmail.com', NULL, 5, 'e10adc3949ba59abbe56e057f20f883e', '', 0, 0, '2017-03-09 20:40:36', 2, NULL, '2021-03-20'),
(10, 'Munna Khan', 'ddddd@demo.com', '1', 4, '93279e3308bdbbeed946fc965017f67a', 'rere@demo.com', 1, 0, '2017-03-13 15:18:51', 2, NULL, '2021-03-20'),
(11, 'Munna Khan', 'rere@demo.com', '', 5, '4297f44b13955235245b2497399d7a93', NULL, 1, 0, '2017-03-20 03:14:41', 2, NULL, '2021-03-20');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `user_role_id` int(5) NOT NULL,
  `user_role_name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`user_role_id`, `user_role_name`) VALUES
(1, 'Super Admin'),
(2, 'Admin'),
(3, 'Moderator'),
(4, 'Teacher'),
(5, 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`ans_id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_id`),
  ADD UNIQUE KEY `code` (`country_code`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `course_sections`
--
ALTER TABLE `course_sections`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `course_videos`
--
ALTER TABLE `course_videos`
  ADD PRIMARY KEY (`video_id`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`currency_id`),
  ADD UNIQUE KEY `code` (`currency_code`);

--
-- Indexes for table `exam_title`
--
ALTER TABLE `exam_title`
  ADD PRIMARY KEY (`title_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `faq_grp`
--
ALTER TABLE `faq_grp`
  ADD PRIMARY KEY (`faq_grp_id`);

--
-- Indexes for table `feature_list`
--
ALTER TABLE `feature_list`
  ADD PRIMARY KEY (`feature_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `messages_reply`
--
ALTER TABLE `messages_reply`
  ADD PRIMARY KEY (`message_reply_id`);

--
-- Indexes for table `noticeboard`
--
ALTER TABLE `noticeboard`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `payment_history`
--
ALTER TABLE `payment_history`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `paypal_settings`
--
ALTER TABLE `paypal_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payu_settings`
--
ALTER TABLE `payu_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price_table`
--
ALTER TABLE `price_table`
  ADD PRIMARY KEY (`price_table_id`);

--
-- Indexes for table `puchase_history`
--
ALTER TABLE `puchase_history`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`ques_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timezone`
--
ALTER TABLE `timezone`
  ADD PRIMARY KEY (`timezone_id`),
  ADD KEY `name` (`timezone_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `ans_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;
--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `country_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `course_sections`
--
ALTER TABLE `course_sections`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `course_videos`
--
ALTER TABLE `course_videos`
  MODIFY `video_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `currency_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- AUTO_INCREMENT for table `exam_title`
--
ALTER TABLE `exam_title`
  MODIFY `title_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `faq_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `faq_grp`
--
ALTER TABLE `faq_grp`
  MODIFY `faq_grp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `feature_list`
--
ALTER TABLE `feature_list`
  MODIFY `feature_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `messages_reply`
--
ALTER TABLE `messages_reply`
  MODIFY `message_reply_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `noticeboard`
--
ALTER TABLE `noticeboard`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `payment_history`
--
ALTER TABLE `payment_history`
  MODIFY `pay_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `paypal_settings`
--
ALTER TABLE `paypal_settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `payu_settings`
--
ALTER TABLE `payu_settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `price_table`
--
ALTER TABLE `price_table`
  MODIFY `price_table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `puchase_history`
--
ALTER TABLE `puchase_history`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `ques_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `result_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `timezone`
--
ALTER TABLE `timezone`
  MODIFY `timezone_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=429;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `user_role_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
